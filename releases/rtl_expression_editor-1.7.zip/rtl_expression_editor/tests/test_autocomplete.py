# -*- coding: utf-8 -*-
"""Custom autocomplete: context detection, and suggestions with and without a
configured lookup table.

Every function/variable name asserted on below (``lower``, ``buffer``, map
scope variables, ...) is read from the live QgsExpression /
QgsExpressionContextUtils API at test time, not hard-coded from memory - the
whole point of sourcing them that way in the plugin itself (see
rtl_autocomplete.builtin_functions/builtin_variables) is that this suite
tracks whatever the installed QGIS version actually registers, so it keeps
passing across QGIS upgrades without needing to be updated by hand.
"""

import unittest

from qgis.core import QgsExpression, QgsFeature, QgsProject
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QPlainTextEdit

from _rtl_plugin import rtl_autocomplete as ac
from _rtl_plugin.rtl_settings import Settings

from .utils import make_context_layer, make_lookup_layer, reset_plugin_settings


class SuggestionContextTests(unittest.TestCase):
    """The three trigger rules: fields after '"', values after "'", the full
    grouped list otherwise - and nothing else (no guessing from a preceding
    operator)."""

    def test_unterminated_double_quote_means_fields(self):
        self.assertEqual(ac.suggestion_context('"NA'), "fields")
        self.assertEqual(ac.suggestion_context('"'), "fields")

    def test_unterminated_single_quote_means_values(self):
        self.assertEqual(ac.suggestion_context("\"NAME\" = 'I"), "values")

    def test_after_at_sign_means_variables(self):
        self.assertEqual(ac.suggestion_context("@ma"), "variables")

    def test_after_an_operator_with_no_quote_is_not_narrowed_to_values(self):
        # Regression: this used to guess "values" from the preceding "=",
        # even with no quote typed at all.
        self.assertEqual(ac.suggestion_context('"CODE" = '), "mixed")

    def test_closed_quotes_and_plain_text_are_mixed(self):
        self.assertEqual(ac.suggestion_context('"NAME" = \'x\' AND '), "mixed")
        self.assertEqual(ac.suggestion_context(""), "mixed")


class DetectFieldNameTests(unittest.TestCase):
    def test_finds_the_nearest_preceding_field(self):
        self.assertEqual(
            ac.detect_field_name('"NAME" = \'x\' AND "COUNTRY" = '), "COUNTRY"
        )

    def test_finds_the_field_being_typed(self):
        self.assertEqual(ac.detect_field_name('"COUN'), "COUN")


class BuiltinFunctionsAndVariablesComeFromTheLiveApiTests(unittest.TestCase):
    """These must be the QGIS installation's own list, not anything hard-coded
    in this suite - every value checked is fetched fresh from QgsExpression
    itself and compared against the plugin's output."""

    def test_every_function_name_is_a_real_registered_function(self):
        live_names = {f.name() for f in QgsExpression.Functions() if not f.name().startswith("_")}
        plugin_names = {name for name, *_rest in ac.builtin_functions()}
        self.assertTrue(plugin_names)
        self.assertTrue(plugin_names.issubset(live_names))

    def test_function_groups_match_qgsexpressions_own_groups(self):
        """Same groups as the Expression Builder, by their translated name
        (e.g. "Geometry", never the raw id "GeometryGroup")."""
        live_groups = {
            f.name(): QgsExpression.group(f.group()) or f.group()
            for f in QgsExpression.Functions()
        }
        for name, _sig, _help, _count, group, _params in ac.builtin_functions():
            if name in live_groups:
                self.assertEqual(group, live_groups[name] or ac.GROUP_FUNCTIONS)

    def test_deprecated_functions_are_not_offered(self):
        deprecated = {f.name() for f in QgsExpression.Functions() if f.isDeprecated()}
        plugin_names = {name for name, *_rest in ac.builtin_functions()}
        self.assertFalse(deprecated & plugin_names)

    def test_functions_carry_their_real_parameter_names(self):
        by_name = {name: params for name, _s, _h, _c, _g, params in ac.builtin_functions()}
        # "buffer" is a long-standing, stable QgsExpression function.
        self.assertIn("buffer", by_name)
        self.assertTrue(by_name["buffer"])

    def test_builtin_variables_include_the_global_scope(self):
        from qgis.core import QgsExpressionContextUtils

        live = set(QgsExpressionContextUtils.globalScope().variableNames())
        plugin = set(ac.builtin_variables())
        self.assertTrue(live.issubset(plugin))


class WithoutAnyLookupTableTests(unittest.TestCase):
    """Autocomplete must work with nothing configured at all - fields from
    the layer being edited, values from the layer's own data."""

    def setUp(self):
        reset_plugin_settings()
        self.layer = make_context_layer(("NAME", "COUNTRY"))
        QgsProject.instance().addMapLayer(self.layer)

    def tearDown(self):
        # Remove only the layer this test added - never every layer in the
        # project, which could be the user's own if this suite is ever run
        # from inside a live QGIS session (e.g. the Settings dialog's "Run
        # Tests" button) rather than a disposable qgis.testing process.
        QgsProject.instance().removeMapLayer(self.layer.id())
        reset_plugin_settings()

    def test_context_field_names_reads_the_layers_own_fields(self):
        self.assertEqual(set(ac.context_field_names(self.layer)), {"NAME", "COUNTRY"})

    def test_layer_first_values_returns_distinct_non_null_values_only(self):
        provider = self.layer.dataProvider()
        for value in ("A", "A", "B", None):
            feature = QgsFeature(self.layer.fields())
            if value is not None:
                feature.setAttribute("NAME", value)
            provider.addFeature(feature)
        values = ac.layer_first_values(self.layer, "NAME", 10)
        # Text values come back quoted - ready to insert as a literal.
        self.assertEqual(set(values), {"'A'", "'B'"})

    def test_layer_first_values_respects_the_limit(self):
        provider = self.layer.dataProvider()
        for value in ("A", "B", "C", "D"):
            feature = QgsFeature(self.layer.fields())
            feature.setAttribute("NAME", value)
            provider.addFeature(feature)
        self.assertEqual(len(ac.layer_first_values(self.layer, "NAME", 2)), 2)


class WithALookupTableTests(unittest.TestCase):
    """Same field/value lookup, now backed by a configured Settings table -
    grouped and described."""

    def setUp(self):
        reset_plugin_settings()
        self.context_layer = make_context_layer(("STATUS", "COUNTRY"))
        self.lookup_layer = make_lookup_layer()
        # The lookup layer is deliberately NOT added to the project - it is
        # read straight from a standalone object, exactly as a real dataset
        # picked from the Browser is (see Settings.autocomplete_layer()).
        # set_layer_for_testing() is the test-only seam for that; a memory
        # layer could not round-trip through the real
        # source-description/URI mechanism (see its own docstring).
        QgsProject.instance().addMapLayer(self.context_layer)

        Settings.set_autocomplete_enabled(True)
        Settings.set_layer_for_testing(self.lookup_layer)
        Settings.set_field("field_names", "field_name")
        Settings.set_field("value", "value")
        Settings.set_field("description", "description")
        Settings.set_field("group_code", "group_code")
        Settings.set_field("group_description", "group_description")
        Settings.set_field("table", "table")
        ac.cache().invalidate()

    def tearDown(self):
        reset_plugin_settings()
        # Only the context layer this test added - see the note in
        # WithoutAnyLookupTableTests.tearDown above.
        QgsProject.instance().removeMapLayers([self.context_layer.id()])
        ac.cache().invalidate()

    def test_configuration_is_usable(self):
        usable, reason = Settings.autocomplete_is_usable()
        self.assertTrue(usable, reason)

    def test_lookup_field_names_come_from_the_configured_table(self):
        self.assertEqual(set(ac.cache().lookup_field_names(["context"])), {"STATUS", "COUNTRY"})

    def test_lookup_values_are_described_and_grouped(self):
        entries = ac.cache().lookup("STATUS", ["context"])
        self.assertEqual(len(entries), 2)
        by_value = {entry.value: entry for entry in entries}
        self.assertEqual(by_value["1"].description, "Active")
        self.assertEqual(ac.plain_text(by_value["1"].group_label), "G1 (State)")

    def test_a_table_not_matching_the_current_layer_returns_nothing(self):
        self.assertEqual(ac.cache().lookup("STATUS", ["some_other_table"]), [])


class AutocompletePopupFlowTests(unittest.TestCase):
    """End-to-end through the real controller and a real QPlainTextEdit -
    the level closest to what actually happens in the Expression Builder."""

    def setUp(self):
        reset_plugin_settings()
        self.layer = make_context_layer(("NAME", "COUNTRY"))
        QgsProject.instance().addMapLayer(self.layer)

        self.editor = QPlainTextEdit()
        # _find_context_layer walks parentWidget() looking for a callable
        # .layer() - stood in directly rather than building a real dialog.
        self.editor.layer = lambda: self.layer
        self.controller = ac.CustomAutocompleteController(self.editor)

    def tearDown(self):
        self.controller.teardown()
        QgsProject.instance().removeMapLayer(self.layer.id())
        reset_plugin_settings()

    def _set_text_and_cursor(self, text: str, position: int) -> None:
        self.editor.setPlainText(text)
        cursor = self.editor.textCursor()
        cursor.setPosition(position)
        self.editor.setTextCursor(cursor)

    def test_ctrl_space_after_a_quote_suggests_the_layers_fields(self):
        self._set_text_and_cursor('"', 1)
        self.controller.trigger()
        values = {entry.value for entry in self.controller._entries}
        self.assertIn('"NAME"', values)
        self.assertIn('"COUNTRY"', values)

    def test_ctrl_space_with_nothing_typed_shows_the_full_grouped_list(self):
        self._set_text_and_cursor("", 0)
        self.controller.trigger()
        groups = {entry.group_label for entry in self.controller._entries if entry.group_label}
        self.assertTrue(groups)  # more than one real function group present

    def test_accepting_a_field_replaces_the_open_quote_exactly_once(self):
        """Regression: selecting NAME after typing "N used to leave the
        opening quote behind and produce ""NAME" instead of "NAME"."""
        self._set_text_and_cursor('"N', 2)
        self.controller.trigger()
        popup = self.controller._popup
        row = next(
            row
            for row in range(popup.count())
            if popup.item(row).data(ac.VALUE_ROLE) == '"NAME"'
        )
        popup.setCurrentRow(row)
        self.controller.accept_current()
        self.assertEqual(self.editor.toPlainText(), '"NAME"')

    def test_fields_popup_title_is_the_layer_name(self):
        """Naming a field: the title says WHICH dataset it belongs to."""
        self._set_text_and_cursor('"', 1)
        self.controller.trigger()
        self.assertEqual(self.controller._popup_title, self.layer.name())

    def test_values_popup_title_is_the_field_name(self):
        """Typing a value: the title says WHICH field it belongs to."""
        provider = self.layer.dataProvider()
        feature = QgsFeature(self.layer.fields())
        feature.setAttribute("NAME", "Foo")
        provider.addFeature(feature)

        text = "\"NAME\" = '"
        self._set_text_and_cursor(text, len(text))
        self.controller.trigger()
        self.assertEqual(self.controller._popup_title, "NAME")

    def test_the_full_grouped_list_has_no_title(self):
        """No single dataset/field applies to the mixed function/variable/
        operator list, so no heading is shown for it."""
        self._set_text_and_cursor("", 0)
        self.controller.trigger()
        self.assertEqual(self.controller._popup_title, "")


class PopupTitleDescriptionEnrichmentTests(unittest.TestCase):
    """The title also shows the dataset's/field's own configured
    description, e.g. "context (הקשר)" or "STATUS (מצב)" - sourced from the
    lookup table's Table description / Field description columns."""

    def setUp(self):
        reset_plugin_settings()
        self.context_layer = make_context_layer(("STATUS", "COUNTRY"))
        self.lookup_layer = make_lookup_layer()
        # Not added to the project - see the note in WithALookupTableTests.setUp.
        QgsProject.instance().addMapLayer(self.context_layer)

        Settings.set_autocomplete_enabled(True)
        Settings.set_layer_for_testing(self.lookup_layer)
        Settings.set_field("field_names", "field_name")
        Settings.set_field("value", "value")
        Settings.set_field("description", "description")
        Settings.set_field("table", "table")
        Settings.set_field("table_description", "table_description")
        Settings.set_field("field_description", "field_description")
        ac.cache().invalidate()

        self.editor = QPlainTextEdit()
        self.editor.layer = lambda: self.context_layer
        self.controller = ac.CustomAutocompleteController(self.editor)

    def tearDown(self):
        self.controller.teardown()
        QgsProject.instance().removeMapLayers([self.context_layer.id()])
        reset_plugin_settings()
        ac.cache().invalidate()

    def _set_text_and_cursor(self, text: str, position: int) -> None:
        self.editor.setPlainText(text)
        cursor = self.editor.textCursor()
        cursor.setPosition(position)
        self.editor.setTextCursor(cursor)

    def test_fields_title_is_enriched_with_the_table_description(self):
        self._set_text_and_cursor('"', 1)
        self.controller.trigger()
        self.assertEqual(ac.plain_text(self.controller._popup_title), "context (הקשר)")

    def test_values_title_is_enriched_with_the_field_description(self):
        text = "\"STATUS\" = '"
        self._set_text_and_cursor(text, len(text))
        self.controller.trigger()
        self.assertEqual(ac.plain_text(self.controller._popup_title), "STATUS (מצב)")

    def test_title_has_no_parenthetical_when_no_description_is_configured(self):
        Settings.set_field("table_description", "")
        Settings.set_field("field_description", "")
        ac.cache().invalidate()

        self._set_text_and_cursor('"', 1)
        self.controller.trigger()
        self.assertEqual(self.controller._popup_title, "context")

    def test_each_field_in_the_fields_list_shows_its_own_description(self):
        """Not just the list's title - each row's own configured Field
        description too, e.g. "STATUS (מצב)" next to "COUNTRY (מדינה)"."""
        self._set_text_and_cursor('"', 1)
        self.controller.trigger()
        displayed = {ac.plain_text(entry.display_text) for entry in self.controller._entries}
        self.assertIn("STATUS (מצב)", displayed)
        self.assertIn("COUNTRY (מדינה)", displayed)

    def test_a_field_with_no_configured_description_shows_its_bare_name(self):
        Settings.set_field("field_description", "")
        ac.cache().invalidate()

        self._set_text_and_cursor('"', 1)
        self.controller.trigger()
        displayed = {entry.display_text for entry in self.controller._entries}
        self.assertIn("STATUS", displayed)
        self.assertNotIn("STATUS (מצב)", displayed)


class AutocompletePopupTitleRenderingTests(unittest.TestCase):
    """AutocompletePopup.populate()'s title row - inserted above every group,
    and sized larger than a group header so the hierarchy stays legible."""

    def setUp(self):
        self.editor = QPlainTextEdit()
        self.popup = ac.AutocompletePopup(self.editor)

    def tearDown(self):
        self.popup.deleteLater()

    def test_title_is_the_first_row_and_not_selectable(self):
        entries = [ac.AutocompleteEntry(value="1", group_code="G1")]
        self.popup.populate(entries, title="STATUS")
        title_item = self.popup.item(0)
        self.assertEqual(title_item.text(), "STATUS")
        self.assertFalse(title_item.flags() & Qt.ItemFlag.ItemIsSelectable)

    def test_no_title_row_when_title_is_empty(self):
        entries = [ac.AutocompleteEntry(value="1")]  # ungrouped, so item(0) is the value itself
        count_without_title = self.popup.populate(entries, title="")
        self.assertEqual(self.popup.item(0).data(ac.VALUE_ROLE), "1")
        self.assertEqual(count_without_title, 1)

    def test_title_font_is_larger_than_a_group_header_font(self):
        entries = [ac.AutocompleteEntry(value="1", group_code="G1")]
        self.popup.populate(entries, title="STATUS")
        title_item = self.popup.item(0)
        header_item = self.popup.item(1)
        # pointSizeF(), not the integer pointSize(): the title's size is
        # only +0.5pt over the base font (a deliberately subtle step - see
        # AutocompletePopup._make_title), which the rounding/truncating
        # integer accessor could report as equal to the (unchanged) header
        # size rather than greater.
        self.assertGreater(title_item.font().pointSizeF(), header_item.font().pointSizeF())
        self.assertTrue(title_item.font().bold())
        self.assertTrue(header_item.font().bold())


class AcceptCurrentInsertsOnlyTheValueTests(unittest.TestCase):
    """accept_current() inserts the chosen value and nothing else - no
    hidden comment, no extra line, regardless of whether the code has one
    meaning or several. An ambiguous code's meaning is resolved later,
    from the expression's own group context, when Read mode renders it
    (see rtl_readmode.substitute_descriptions()/_pick_label()) - nothing
    about accepting a suggestion needs to remember which one was meant."""

    def setUp(self):
        reset_plugin_settings()
        self.context_layer = make_context_layer(("STATUS", "COUNTRY"))
        self.lookup_layer = make_lookup_layer()
        # Not added to the project - see the note in WithALookupTableTests.setUp.
        QgsProject.instance().addMapLayer(self.context_layer)

        Settings.set_autocomplete_enabled(True)
        Settings.set_layer_for_testing(self.lookup_layer)
        Settings.set_field("field_names", "field_name")
        Settings.set_field("value", "value")
        Settings.set_field("description", "description")
        Settings.set_field("table", "table")
        ac.cache().invalidate()

        self.editor = QPlainTextEdit()
        self.editor.layer = lambda: self.context_layer
        self.controller = ac.CustomAutocompleteController(self.editor)

    def tearDown(self):
        self.controller.teardown()
        QgsProject.instance().removeMapLayers([self.context_layer.id()])
        reset_plugin_settings()

    def test_accepting_an_ambiguous_value_inserts_only_the_value(self):
        text = "\"STATUS\" = '1"
        self.editor.setPlainText(text)
        cursor = self.editor.textCursor()
        cursor.setPosition(len(text))
        self.editor.setTextCursor(cursor)
        self.controller.trigger()
        popup = self.controller._popup
        row = next(
            row for row in range(popup.count()) if popup.item(row).data(ac.VALUE_ROLE) == "1"
        )
        popup.setCurrentRow(row)
        self.controller.accept_current()

        result = self.editor.toPlainText()
        self.assertNotIn("\n", result)
        self.assertNotIn("/*", result)
        self.assertTrue(result.startswith('"STATUS" = '))


class VariableSuggestionTests(unittest.TestCase):
    """Variables come from the dialog's own expression context, so map
    variables such as @map_scale are offered - and accepting one never
    doubles the "@"."""

    def setUp(self):
        from qgis.core import QgsExpressionContext, QgsExpressionContextUtils, QgsMapSettings

        reset_plugin_settings()
        context = QgsExpressionContext()
        context.appendScope(QgsExpressionContextUtils.globalScope())
        context.appendScope(QgsExpressionContextUtils.mapSettingsScope(QgsMapSettings()))
        self.context = context
        self.editor = QPlainTextEdit()
        # Stands in for the Expression Builder's expressionContext().
        self.editor.expressionContext = lambda: self.context
        self.controller = ac.CustomAutocompleteController(self.editor)

    def tearDown(self):
        self.controller.teardown()
        reset_plugin_settings()

    def _set_text(self, text: str) -> None:
        self.editor.setPlainText(text)
        cursor = self.editor.textCursor()
        cursor.setPosition(len(text))
        self.editor.setTextCursor(cursor)

    def _accept(self, value: str) -> None:
        popup = self.controller._popup
        row = next(r for r in range(popup.count()) if popup.item(r).data(ac.VALUE_ROLE) == value)
        popup.setCurrentRow(row)
        self.controller.accept_current()

    def test_map_scale_is_offered_from_the_dialog_context(self):
        self.assertIn("map_scale", ac.builtin_variables(None, self.editor))

    def test_typing_at_sign_offers_map_scale(self):
        self._set_text("@")
        self.controller.trigger()
        values = {entry.value for entry in self.controller._entries}
        self.assertIn("@map_scale", values)

    def test_accepting_a_variable_does_not_double_the_at_sign(self):
        self._set_text("@map_s")
        self.controller.trigger()
        self._accept("@map_scale")
        self.assertEqual(self.editor.toPlainText(), "@map_scale")

    def test_variables_are_found_without_the_at_sign_in_the_full_list(self):
        self._set_text("map_sc")
        self.controller.trigger()
        self._accept("@map_scale")
        self.assertEqual(self.editor.toPlainText(), "@map_scale")

    def test_hidden_variables_are_not_offered(self):
        names = ac.builtin_variables(None, self.editor)
        self.assertFalse([name for name in names if name.startswith("_")])


class RtlAndQuotedTokenTests(unittest.TestCase):
    """Typing inside quotes: Hebrew letters and spaces are part of the
    token, so accepting replaces everything typed since the quote."""

    def setUp(self):
        reset_plugin_settings()
        self.layer = make_context_layer(("NAME", "COUNTRY"))
        provider = self.layer.dataProvider()
        for value in ("בית ספר", "בית חולים", "New York"):
            feature = QgsFeature(self.layer.fields())
            feature.setAttribute("NAME", value)
            provider.addFeature(feature)
        QgsProject.instance().addMapLayer(self.layer)
        self.editor = QPlainTextEdit()
        self.editor.layer = lambda: self.layer
        self.controller = ac.CustomAutocompleteController(self.editor)

    def tearDown(self):
        self.controller.teardown()
        QgsProject.instance().removeMapLayer(self.layer.id())
        reset_plugin_settings()

    def _set_text(self, text: str, position: int = -1) -> None:
        self.editor.setPlainText(text)
        cursor = self.editor.textCursor()
        cursor.setPosition(len(text) if position < 0 else position)
        self.editor.setTextCursor(cursor)

    def test_hebrew_partial_value_with_a_space_is_matched_and_replaced(self):
        self._set_text('"NAME" = \'בית ס')
        self.controller.trigger()
        matches = self.controller._matches(
            self.controller._entries, self.controller._current_token()
        )
        self.assertEqual([entry.value for entry in matches], ["'בית ספר'"])
        self.controller.accept_current()
        self.assertEqual(self.editor.toPlainText(), '"NAME" = \'בית ספר\'')

    def test_latin_value_with_a_space_is_replaced_whole(self):
        self._set_text('"NAME" = \'New Y')
        self.controller.trigger()
        self.controller.accept_current()
        self.assertEqual(self.editor.toPlainText(), '"NAME" = \'New York\'')

    def test_a_closing_quote_after_the_caret_is_not_doubled(self):
        text = '"NAME" = \'New Y\''
        self._set_text(text, len(text) - 1)
        self.controller.trigger()
        self.controller.accept_current()
        self.assertEqual(self.editor.toPlainText(), '"NAME" = \'New York\'')

    def test_hebrew_letters_and_spaces_do_not_end_a_value_token(self):
        self.controller._field_mode = False
        self.controller._value_mode = True
        self.assertFalse(self.controller._ends_token("ב"))
        self.assertFalse(self.controller._ends_token(" "))
        self.assertTrue(self.controller._ends_token("\'"))

    def test_hebrew_letters_continue_an_unquoted_token(self):
        self.controller._field_mode = False
        self.controller._value_mode = False
        self.assertFalse(self.controller._ends_token("ש"))
        self.assertTrue(self.controller._ends_token(" "))

    def test_the_full_list_includes_the_layers_fields(self):
        self._set_text("NA")
        self.controller.trigger()
        values = {entry.value for entry in self.controller._entries}
        self.assertIn('"NAME"', values)


class ValueLiteralTests(unittest.TestCase):
    """Lookup values are inserted as valid literals for the target field."""

    def test_text_is_quoted(self):
        self.assertEqual(ac.value_literal("farm"), "'farm'")

    def test_embedded_quotes_are_escaped(self):
        self.assertEqual(ac.value_literal("O'Hara"), "'O''Hara'")

    def test_an_already_quoted_value_is_kept(self):
        self.assertEqual(ac.value_literal("'farm'"), "'farm'")

    def test_numbers_stay_bare_for_numeric_or_unknown_fields(self):
        self.assertEqual(ac.value_literal("12", numeric=True), "12")
        self.assertEqual(ac.value_literal("12", numeric=None), "12")

    def test_numbers_are_quoted_for_text_fields(self):
        self.assertEqual(ac.value_literal("12", numeric=False), "'12'")


if __name__ == "__main__":
    unittest.main()
