# -*- coding: utf-8 -*-
"""
Custom autocomplete source for the RTL / BiDi editor plugin.

This module is **purely additive**.  Nothing here touches the overlay editor's
synchronisation, geometry, appearance or detection logic.  The single
integration point is ``CustomAutocompleteController``, which:

* installs an event filter on the overlay editor to catch Ctrl+Space, and
* inserts the chosen value with ``QTextCursor.insertText()``.

That second point matters: the insertion is an ordinary edit on the overlay's
document, so it flows through the *existing* ``textChanged`` -> Scintilla push
exactly like a keystroke.  The synchronisation mechanism is reused, not
modified, and not bypassed.

Design notes
------------
**No layer scanning.**  Values are fetched with a provider-side
``QgsFeatureRequest`` filter expression, so a lookup reads only the handful of
matching rows.  On a PostGIS or GeoPackage source the filter is pushed down to
the database.  A full-table scan never happens, which is why no background
``QgsTask`` is needed to keep the GUI responsive.

**Per-key memoisation.**  Results are cached under
``(field_name, table_context)``.  Repeated Ctrl+Space on the same field costs
nothing.  The cache is dropped when settings change, when the source layer's
data changes, or when the layer is removed from the project.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional, Sequence, Tuple

from qgis.PyQt.QtCore import QEvent, QObject, Qt
from qgis.PyQt.QtGui import QColor, QFont, QTextCursor
from qgis.PyQt.QtWidgets import (
    QApplication,
    QLabel,
    QListWidget,
    QListWidgetItem,
)

from qgis.core import Qgis, QgsExpression, QgsFeatureRequest, QgsMessageLog

from .rtl_settings import BUS, Settings

LOG_TAG = "RTL Expression Editor"

#: Hard ceiling on rows pulled per lookup.  Protects against a misconfigured
#: field selector turning into an unbounded read.
QUERY_LIMIT = 2000

#: Maximum items shown in the popup at once.
MAX_DISPLAYED = 500

#: Vertical breathing room between the caret's text line and any popup
#: placed above or below it, so neither the call tip nor the suggestion
#: list sits close enough to overlap the very text it is describing.
POPUP_VERTICAL_GAP = 10

#: Characters that make up a value token being typed before the cursor.
_TOKEN_RE = re.compile(r"[A-Za-z0-9_\-.]+$")

#: A single character that continues a token rather than ending it - used to
#: decide whether a just-typed key should close the completion popup.
_CONTINUATION_CHAR_RE = re.compile(r"[A-Za-z0-9_\-.]")

#: A field name in double quotes, e.g. "COUNTRY".
_QUOTED_FIELD_RE = re.compile(r'"([^"\n]+)"')

#: An unterminated quote at the very end, e.g. ... "COUN
_OPEN_QUOTE_RE = re.compile(r'"([^"\n]*)$')

#: A single-quoted string literal, blanked out before quote counting.
_SQ_STRING_RE = re.compile(r"'(?:[^'\\\n]|\\.)*'")

#: Roles used to carry the insertable value on popup items.
VALUE_ROLE = int(Qt.ItemDataRole.UserRole) + 1
#: Description carried alongside the value, for remembering the user's choice.
DESC_ROLE = int(Qt.ItemDataRole.UserRole) + 2
#: Text to insert, which differs from the displayed label for functions.
INSERT_ROLE = int(Qt.ItemDataRole.UserRole) + 3
#: Characters to move the caret left after inserting.
CARET_ROLE = int(Qt.ItemDataRole.UserRole) + 4


#: Diagnostic logging for the Ctrl+Space path.
#:
#: Off by default, and deliberately so: writing to the QGIS message log can
#: cause the Log Messages dock to be raised, which pulls keyboard focus off a
#: modal dialog. In the Expression Builder that leaves the caret invisible until
#: the dialog is reopened. Set to True only while diagnosing, or better, call
#: diagnose() from the Python Console, which prints instead of logging.
DEBUG_AC = False

#: When a table-filtered lookup finds nothing, retry without the table clause.
#:
#: OFF: values are returned only when the current layer's source table name
#: appears in the configured Table Field. A mismatch yields no popup, which is
#: the intended, strict behaviour. Use diagnose() to investigate a mismatch -
#: never the message log, see DEBUG_AC.
TABLE_FILTER_FALLBACK = False


def _log(message: str, level=Qgis.MessageLevel.Info) -> None:
    """Log a genuine problem.  Never called on the normal Ctrl+Space path."""
    try:
        QgsMessageLog.logMessage(message, LOG_TAG, level)
    except Exception:
        pass


def _dbg(message: str) -> None:
    """Diagnostic-only logging; silent unless DEBUG_AC is enabled."""
    if DEBUG_AC:
        _log(message, Qgis.MessageLevel.Info)


# --------------------------------------------------------------------------- #
# Data model
# --------------------------------------------------------------------------- #


def _unquote_for_display(text: str) -> str:
    """Strip one layer of matching outer quotes, for DISPLAY only.

    A lookup table may store codes with their quotes included, e.g. the literal
    seven characters ``'farm'``, so that double-clicking inserts a ready-made SQL
    string. Showing that raw in the popup gives ``'farm' (300)``, which is noisy.

    This affects only what the popup renders and what typing filters against.
    The value inserted into the expression comes from the entry's raw ``value``,
    so a code stored with quotes still produces valid SQL.

    Uses the same single-matching-pair rule as rtl_readmode.normalize_code, so
    the popup and read mode agree on what "unquoted" means.
    """
    value = (text or "").strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
        return value[1:-1].strip()
    return value


class AutocompleteEntry:
    """One candidate value, plus the optional labels used to present it."""

    __slots__ = (
        "value",
        "description",
        "group_code",
        "group_description",
        "insert_text",
        "display_text",
        "help_text",
        "caret_offset",
    )

    def __init__(
        self,
        value: str,
        description: str = "",
        group_code: str = "",
        group_description: str = "",
        insert_text: str = "",
        display_text: str = "",
        help_text: str = "",
        caret_offset: int = 0,
    ):
        self.value = value
        self.description = description
        self.group_code = group_code
        self.group_description = group_description
        #: What actually goes into the document. Defaults to ``value``. A
        #: function displays ``buffer(geometry, distance)`` but inserts
        #: ``buffer()``, so the two must be separable.
        self.insert_text = insert_text or value
        #: Overrides the computed label when set.
        self.display_text = display_text
        #: Tooltip - QGIS help text is HTML, which Qt tooltips render natively.
        self.help_text = help_text
        #: Characters to move the caret LEFT after inserting, so ``buffer()``
        #: leaves the caret between the parentheses.
        self.caret_offset = caret_offset

    @property
    def display(self) -> str:
        """Label shown in the popup: ``IL (Israel)`` or just ``IL``.

        Quotes are stripped for presentation only - see _unquote_for_display.
        """
        if self.display_text:
            return self.display_text
        value = _unquote_for_display(self.value)
        description = _unquote_for_display(self.description)
        if description:
            return f"{value} ({description})"
        return value

    @property
    def filter_text(self) -> str:
        """Text typing is matched against: unquoted value plus description."""
        return f"{_unquote_for_display(self.value)} {_unquote_for_display(self.description)}"

    @property
    def group_label(self) -> str:
        """Header label: ``Country Codes (International)``."""
        code = _unquote_for_display(self.group_code)
        description = _unquote_for_display(self.group_description)
        if code and description:
            return f"{code} ({description})"
        return code or description or ""


# --------------------------------------------------------------------------- #
# Field-name detection
# --------------------------------------------------------------------------- #


#: Group headings used by the mixed suggestion list.
GROUP_FIELDS = "Fields"
GROUP_FUNCTIONS = "Functions"
GROUP_VARIABLES = "Variables"
GROUP_OPERATORS = "Operators"
GROUP_VALUES = "Values"

#: Static operator/keyword list. Not obtainable from any API.
_OPERATORS = (
    "AND", "OR", "NOT", "IN", "LIKE", "ILIKE", "IS NULL", "IS NOT NULL",
    "BETWEEN", "CASE WHEN", "THEN", "ELSE", "END",
)

#: Cache for the function index - QgsExpression.Functions() is stable for a
#: session, and building signatures for several hundred functions on every
#: keypress would be wasteful.
_FUNCTION_CACHE: Optional[List[tuple]] = None


def builtin_functions() -> List[tuple]:
    """Return ``(name, signature, help_html, param_count, group, params)``.

    Scintilla's own completion cannot be reused from an overlay (it needs to own
    the input loop to filter and accept entries), so the list is rebuilt from
    the public API instead. That also lets us show signatures and help text,
    which Scintilla's plain list does not.

    ``group`` is the function's own category (Aggregates, Arrays, Color,
    Conditionals, Geometry, Operators, ...) exactly as QgsExpression reports
    it - the same string the Expression Builder's tree groups functions by -
    so the autocomplete popup groups them identically instead of lumping every
    function under one generic heading.
    """
    global _FUNCTION_CACHE
    if _FUNCTION_CACHE is not None:
        return _FUNCTION_CACHE

    functions: List[tuple] = []
    try:
        for function in QgsExpression.Functions():
            try:
                name = function.name()
                if not name or name.startswith("_"):
                    continue

                params: List[str] = []
                try:
                    for parameter in function.parameters():
                        param_name = parameter.name()
                        if param_name:
                            params.append(param_name)
                except Exception:
                    # Not every function exposes parameters; variadic ones in
                    # particular may report none. Fall back to an empty
                    # signature rather than dropping the function.
                    params = []

                signature = f"{name}({', '.join(params)})" if params else f"{name}()"
                try:
                    help_html = function.helpText() or ""
                except Exception:
                    help_html = ""
                try:
                    group = function.group() or GROUP_FUNCTIONS
                except Exception:
                    group = GROUP_FUNCTIONS
                functions.append((name, signature, help_html, len(params), group, params))
            except Exception:
                continue
    except Exception as exc:
        _dbg(f"Could not enumerate functions: {exc}")

    functions.sort(key=lambda item: item[0].lower())
    _FUNCTION_CACHE = functions
    return functions


def builtin_variables(layer=None) -> List[str]:
    """Variable names from the global, project and layer scopes.

    Covers @map_scale, @atlas_feature, project variables and any custom ones,
    correctly scoped, without hard-coding a list that would go stale.
    """
    names: List[str] = []
    seen = set()

    def add_scope(scope) -> None:
        if scope is None:
            return
        try:
            for name in scope.variableNames():
                if name and name not in seen:
                    seen.add(name)
                    names.append(name)
        except Exception:
            pass

    try:
        from qgis.core import QgsExpressionContextUtils, QgsProject

        add_scope(QgsExpressionContextUtils.globalScope())
        add_scope(QgsExpressionContextUtils.projectScope(QgsProject.instance()))
        if layer is not None:
            add_scope(QgsExpressionContextUtils.layerScope(layer))
    except Exception as exc:
        _dbg(f"Could not enumerate variables: {exc}")

    names.sort(key=str.lower)
    return names


def context_field_names(layer) -> List[str]:
    """Field names of the layer being edited."""
    if layer is None:
        return []
    try:
        return [field.name() for field in layer.fields()]
    except Exception:
        return []


def layer_first_values(layer, field_name: str, limit: int) -> List[str]:
    """The first ``limit`` distinct, non-null values of ``field_name``.

    Used when no lookup table is configured for this field (or it has
    nothing for it): rather than offering no values at all, the field's own
    data stands in. Each value comes back already wrapped for insertion -
    quoted for text, bare for numbers - via ``QgsExpression.quotedValue()``,
    which is exactly what a hand-typed literal would need.
    """
    if layer is None or not field_name or limit <= 0:
        return []
    try:
        index = layer.fields().indexOf(field_name)
        if index < 0:
            return []
    except Exception:
        return []

    values: List[str] = []
    seen = set()
    try:
        # uniqueValues() may include NULL among its results, so ask for a
        # little more than we need and stop once enough real values are found.
        for raw in layer.uniqueValues(index, limit + 5):
            if raw is None:
                continue
            try:
                if hasattr(raw, "isNull") and raw.isNull():
                    continue
            except Exception:
                pass
            text_key = str(raw).strip().lower()
            if not text_key or text_key in seen:
                continue
            seen.add(text_key)
            try:
                literal = QgsExpression.quotedValue(raw)
            except Exception:
                literal = QgsExpression.quotedString(str(raw))
            values.append(literal)
            if len(values) >= limit:
                break
    except Exception as exc:
        _dbg(f"Layer value fallback failed: {exc}")
        return []
    return values


#: Caret sitting immediately after @ or partway through a variable name.
_VARIABLE_RE = re.compile(r"@(\w*)$")


def suggestion_context(text_before_cursor: str) -> str:
    """Decide WHAT to suggest from the text before the caret.

    Three simple, purely syntactic rules, checked in order - no guessing from
    surrounding operators or keywords:

    * inside an unterminated ``"`` -> naming a field.
    * immediately after ``@``      -> a variable.
    * inside an unterminated ``'`` -> typing a value.
    * anything else                -> "mixed": the full list of functions,
      variables and operators. This also covers sitting right after ``=``,
      ``AND``, ``IN`` and the like with no quote typed yet - the suggestion
      is not narrowed to values there, since nothing was actually typed to
      say that is what is wanted.

    Returns one of: "fields", "variables", "values", "mixed".
    """
    if not text_before_cursor:
        return "mixed"

    scrubbed = _SQ_STRING_RE.sub(
        lambda m: " " * (m.end() - m.start()), text_before_cursor
    )

    # Inside an unterminated double quote -> naming a field.
    if scrubbed.count('"') % 2 == 1:
        return "fields"

    # Immediately after @ -> a variable.
    if _VARIABLE_RE.search(text_before_cursor):
        return "variables"

    # Inside an unterminated single quote -> typing a value.
    without_fields = re.sub(r'"[^"\n]*"', lambda m: " " * len(m.group(0)), text_before_cursor)
    if without_fields.count("'") % 2 == 1:
        return "values"

    return "mixed"


def detect_field_name(text_before_cursor: str) -> str:
    """Extract the field name the cursor is currently working on.

    Scans backwards from the cursor for the nearest double-quoted token, which
    is how both the expression language and the SQL filter spell a field
    reference.

    Two cases are distinguished by counting double quotes, because a naive
    "search backwards for a quote" also matches the text *after* a closing
    quote:

    * **even** number of quotes - every quoted token is closed, so the caret is
      somewhere after a complete field reference. The nearest one wins.
    * **odd** number - the caret sits inside an unterminated token, i.e. the
      user is still typing the field name itself.

    Single-quoted string literals are blanked out before counting, so a stray
    double quote inside a literal (``'say "hi"'``) cannot corrupt the parity.
    Blanking preserves length, keeping all offsets valid.

    >>> detect_field_name('"NAME" = \\'x\\' AND "COUNTRY" = ')
    'COUNTRY'
    >>> detect_field_name('"COUN')
    'COUN'
    """
    if not text_before_cursor:
        return ""

    scrubbed = _SQ_STRING_RE.sub(lambda m: " " * (m.end() - m.start()), text_before_cursor)

    if scrubbed.count('"') % 2 == 1:
        open_quote = _OPEN_QUOTE_RE.search(scrubbed)
        return open_quote.group(1).strip() if open_quote else ""

    matches = list(_QUOTED_FIELD_RE.finditer(scrubbed))
    return matches[-1].group(1).strip() if matches else ""


def _strip_quotes(name: str) -> str:
    """Remove the quoting a provider URI may wrap a table name in."""
    name = (name or "").strip()
    for quote in ('"', "'", "`", "[", "]"):
        name = name.strip(quote)
    return name.strip()


def source_table_name(layer) -> str:
    """The layer's *source table* name - not its display name.

    Uses ``QgsProviderRegistry.decodeUri()``, which is provider-aware and is the
    only reliable way to do this across backends.  ``QgsDataSourceUri`` alone is
    not enough: it understands the ``key=value`` form used by Postgres/MSSQL but
    returns an empty table for OGR sources, which is why an earlier version of
    this function silently fell back to the layer name.

    Examples::

        .../world_map.gpkg|layername=countries|subset="NAME" 20   -> countries
        dbname='test' ... table="public"."World Map" (geom)       -> World Map
        /data/roads.shp                                          -> roads
    """
    if layer is None:
        return ""

    source = ""
    try:
        source = layer.source() or ""
    except Exception:
        pass

    # 1. Provider-aware decode. Returns 'layerName' for OGR/GPKG and 'table'
    #    (plus a separate 'schema') for database providers.
    try:
        from qgis.core import QgsProviderRegistry

        parts = QgsProviderRegistry.instance().decodeUri(layer.providerType(), source)
        if isinstance(parts, dict):
            for key in ("layerName", "table", "tableName"):
                value = parts.get(key)
                if value not in (None, ""):
                    name = _strip_quotes(str(value))
                    if name:
                        return name
    except Exception:
        pass

    # 2. key=value URI form (Postgres, MSSQL, Oracle...).
    try:
        from qgis.core import QgsDataSourceUri

        table = QgsDataSourceUri(source).table()
        if table:
            return _strip_quotes(table)
    except Exception:
        pass

    # 3. Textual fallbacks, in case a provider is not registered.
    match = re.search(r"layername=([^|]+)", source, re.IGNORECASE)
    if match:
        return _strip_quotes(match.group(1))
    match = re.search(r'table=(?:"[^"]*"\.)?("[^"]+"|[^\s(]+)', source, re.IGNORECASE)
    if match:
        return _strip_quotes(match.group(1))

    # 4. File-based source with no layer name: the file stem is the table.
    try:
        import os

        path = source.split("|")[0].strip()
        if path and (os.sep in path or "/" in path):
            stem = os.path.splitext(os.path.basename(path))[0]
            if stem:
                return stem
    except Exception:
        pass

    return ""


def _find_context_layer(widget):
    """The layer the dialog is operating on.

    Two strategies, in order of reliability:

    1. Walk up from the Scintilla widget for an ancestor exposing ``layer()``.
       This is the same technique the editor already uses to harvest field
       names, so no new assumption is introduced. It covers the Expression
       Builder and the Field Calculator.
    2. Fall back to ``iface.activeLayer()``. The Query Builder does not expose
       its layer to Python, but it is always opened from the layer that is
       active in the layer tree, so this is accurate in practice.
    """
    try:
        node = widget
        depth = 0
        while node is not None and depth < 10:
            getter = getattr(node, "layer", None)
            if callable(getter):
                try:
                    candidate = getter()
                    if candidate is not None and hasattr(candidate, "source"):
                        return candidate
                except Exception:
                    pass
            node = node.parentWidget() if hasattr(node, "parentWidget") else None
            depth += 1
    except Exception:
        pass

    # 2. Fall back to the active layer, but never to the autocomplete lookup
    #    layer itself: if the user has the lookup table selected in the layer
    #    tree, activeLayer() would return it, and the table filter would then
    #    compare the lookup table against its own name and match nothing.
    try:
        from qgis.utils import iface

        if iface is not None:
            active = iface.activeLayer()
            if active is not None and hasattr(active, "source"):
                lookup = Settings.autocomplete_layer()
                if lookup is not None and active.id() == lookup.id():
                    _dbg(
                        "Autocomplete: the active layer IS the lookup layer; "
                        "no table context could be determined."
                    )
                    return None
                return active
    except Exception:
        pass
    return None


def resolve_table_candidates(widget) -> List[str]:
    """Values to match against the configured Table Field.

    The **source table name is authoritative** - that is what the user
    configures against:

        .../world_map.gpkg|layername=countries|subset="NAME" 20  -> countries
        dbname='test' ... table="public"."World Map" (geom)      -> World Map

    Only two spellings are returned: the bare table name, and - for database
    providers - the schema-qualified form. The qualified form is strictly
    narrower, so OR-ing it can never let through a row that the bare name would
    not already match.

    The layer's display name and the container file's stem are used *only* when
    the source table name cannot be determined at all. Earlier this function
    OR-ed all four spellings together on the theory that the user should not
    have to guess the convention; in practice that widened the filter and let
    rows from other tables through, e.g. matching ``world_map`` (the file stem)
    when the table is ``countries``.

    An empty list means "the table context is unknown", which the caller now
    treats as "return nothing" rather than "match every table".
    """
    layer = _find_context_layer(widget)
    if layer is None:
        _dbg("Autocomplete: could not determine the current layer.")
        return []

    candidates: List[str] = []

    def add(value: str) -> None:
        value = (value or "").strip()
        if value and not any(value.lower() == existing.lower() for existing in candidates):
            candidates.append(value)

    table = source_table_name(layer)
    add(table)

    # Schema-qualified variant, e.g. public.World Map.
    if table:
        try:
            from qgis.core import QgsProviderRegistry

            parts = QgsProviderRegistry.instance().decodeUri(
                layer.providerType(), layer.source()
            )
            if isinstance(parts, dict):
                schema = str(parts.get("schema") or "").strip()
                if schema:
                    add(f"{schema}.{table}")
        except Exception:
            pass
    else:
        # No source table could be determined - fall back to looser spellings
        # rather than disabling the feature entirely.
        _dbg("Autocomplete: no source table name; falling back to layer name.")
        try:
            add(layer.name())
        except Exception:
            pass
        try:
            import os

            path = (layer.source() or "").split("|")[0].strip()
            if path and (os.sep in path or "/" in path):
                add(os.path.splitext(os.path.basename(path))[0])
        except Exception:
            pass

    _dbg(f"Autocomplete table context: {candidates}")
    return candidates


# --------------------------------------------------------------------------- #
# Cache / lookup
# --------------------------------------------------------------------------- #


class AutocompleteCache(QObject):
    """Memoised, provider-filtered lookups against the configured layer.

    One instance is shared by every overlay editor (see ``cache()`` below), so
    opening several dialogs does not multiply the queries.
    """

    def __init__(self, parent: Optional[QObject] = None):
        super().__init__(parent)
        self._memo: Dict[Tuple[str, str], List[AutocompleteEntry]] = {}
        self._watched_layer_id: str = ""
        self._watched_layer = None
        BUS.changed.connect(self.invalidate)

    # -- invalidation ------------------------------------------------------ #

    def invalidate(self) -> None:
        """Drop everything.  Called on settings change and on layer edits."""
        self._memo.clear()
        self._sync_layer_hooks()

    def _sync_layer_hooks(self) -> None:
        """Keep edit-signal connections pointed at the configured layer."""
        layer = Settings.autocomplete_layer()
        layer_id = layer.id() if layer is not None else ""
        if layer_id == self._watched_layer_id:
            return

        # Disconnect the previous layer.
        if self._watched_layer is not None:
            for signal_name in (
                "dataChanged",
                "featureAdded",
                "featuresDeleted",
                "attributeValueChanged",
                "willBeDeleted",
            ):
                try:
                    getattr(self._watched_layer, signal_name).disconnect(self._on_layer_touched)
                except Exception:
                    pass

        self._watched_layer = layer
        self._watched_layer_id = layer_id

        if layer is None:
            return
        for signal_name in (
            "dataChanged",
            "featureAdded",
            "featuresDeleted",
            "attributeValueChanged",
            "willBeDeleted",
        ):
            try:
                getattr(layer, signal_name).connect(self._on_layer_touched)
            except Exception:
                pass  # not every provider exposes every signal

    def _on_layer_touched(self, *_args) -> None:
        self._memo.clear()

    # -- lookup ------------------------------------------------------------ #

    def lookup(self, field_name: str, table_candidates: Sequence[str]) -> List[AutocompleteEntry]:
        """Return sorted entries for ``field_name`` in the given table context."""
        if not field_name:
            return []
        usable, reason = Settings.autocomplete_is_usable()
        if not usable:
            _dbg(f"Custom autocomplete unavailable: {reason}")
            return []

        self._sync_layer_hooks()

        key = (field_name.strip().lower(), "|".join(sorted(t.lower() for t in table_candidates)))
        if key in self._memo:
            return self._memo[key]

        entries = self._query(field_name, table_candidates)
        entries.sort(key=lambda e: (e.group_label.lower(), e.value.lower()))
        self._memo[key] = entries
        return entries

    def lookup_field_names(self, table_candidates: Sequence[str]) -> List[str]:
        """Distinct values of the Fields Names column for this table context.

        Powers field-name completion: the user types a quote and gets the list
        of fields that actually have definitions, instead of having to remember
        them. Memoised under a reserved key alongside the value lookups.
        """
        usable, _ = Settings.autocomplete_is_usable()
        if not usable:
            return []
        self._sync_layer_hooks()

        key = ("\x00field-names", "|".join(sorted(t.lower() for t in table_candidates)))
        cached = self._memo.get(key)
        if cached is not None:
            return [entry.value for entry in cached]

        layer = Settings.autocomplete_layer()
        f_names = Settings.field("field_names")
        f_table = Settings.field("table")
        names: List[str] = []
        seen = set()
        try:
            request = QgsFeatureRequest()
            if f_table and table_candidates:
                column = QgsExpression.quotedColumnRef(f_table)
                ors = " OR ".join(
                    f"lower(trim({column})) = {QgsExpression.quotedString(t.lower())}"
                    for t in table_candidates
                )
                request.setFilterExpression(ors)
            request.setLimit(QUERY_LIMIT)
            try:
                request.setFlags(QgsFeatureRequest.Flag.NoGeometry)
            except Exception:
                pass
            for feature in layer.getFeatures(request):
                value = self._as_text(feature, f_names)
                if value and value.lower() not in seen:
                    seen.add(value.lower())
                    names.append(value)
        except Exception as exc:
            _dbg(f"Field-name lookup failed: {exc}")
            return []

        names.sort(key=str.lower)
        self._memo[key] = [AutocompleteEntry(value=n) for n in names]
        return names

    def lookup_field_descriptions(self, table_candidates: Sequence[str]) -> Dict[str, str]:
        """``field name (lowercased) -> its Field description column value``,
        for every field with one configured in this table context.

        Built in one query pass (unlike ``lookup_field_description()``,
        which looks up a single field) so the fields suggestion list can
        show every row's own description at once, e.g. "type (סוג)",
        without one query per field. Empty when no Field description column
        is configured.
        """
        usable, _ = Settings.autocomplete_is_usable()
        f_field_desc = Settings.field("field_description")
        f_names = Settings.field("field_names")
        if not (usable and f_field_desc and f_names):
            return {}
        self._sync_layer_hooks()

        key = ("\x00field-descriptions", "|".join(sorted(t.lower() for t in table_candidates)))
        cached = self._memo.get(key)
        if cached is not None:
            return {entry.value: entry.description for entry in cached}

        layer = Settings.autocomplete_layer()
        f_table = Settings.field("table")
        descriptions: Dict[str, str] = {}
        try:
            request = QgsFeatureRequest()
            if f_table and table_candidates:
                column = QgsExpression.quotedColumnRef(f_table)
                ors = " OR ".join(
                    f"lower(trim({column})) = {QgsExpression.quotedString(t.lower())}"
                    for t in table_candidates
                )
                request.setFilterExpression(ors)
            request.setLimit(QUERY_LIMIT)
            try:
                request.setFlags(QgsFeatureRequest.Flag.NoGeometry)
            except Exception:
                pass
            for feature in layer.getFeatures(request):
                field = self._as_text(feature, f_names).lower()
                if not field or field in descriptions:
                    continue
                description = self._as_text(feature, f_field_desc)
                if description:
                    descriptions[field] = description
        except Exception as exc:
            _dbg(f"Field-descriptions lookup failed: {exc}")
            return {}

        self._memo[key] = [
            AutocompleteEntry(value=field, description=description)
            for field, description in descriptions.items()
        ]
        return descriptions

    def lookup_table_description(self, table_candidates: Sequence[str]) -> str:
        """The Table description column's value for this table context, if
        configured and found - e.g. table 'buildings' described as 'מבנים'.
        Used to enrich the fields suggestion list's title (see
        ``CustomAutocompleteController._layer_display_name``). Empty string
        when no such column is configured, or nothing matches.
        """
        usable, _ = Settings.autocomplete_is_usable()
        f_table_desc = Settings.field("table_description")
        f_table = Settings.field("table")
        if not (usable and f_table_desc and f_table and table_candidates):
            return ""
        self._sync_layer_hooks()

        key = ("\x00table-desc", "|".join(sorted(t.lower() for t in table_candidates)))
        cached = self._memo.get(key)
        if cached is not None:
            return cached[0].value if cached else ""

        layer = Settings.autocomplete_layer()
        description = ""
        try:
            column = QgsExpression.quotedColumnRef(f_table)
            ors = " OR ".join(
                f"lower(trim({column})) = {QgsExpression.quotedString(t.lower())}"
                for t in table_candidates
            )
            request = QgsFeatureRequest().setFilterExpression(ors)
            request.setLimit(50)  # the first non-empty match is enough
            try:
                request.setFlags(QgsFeatureRequest.Flag.NoGeometry)
            except Exception:
                pass
            for feature in layer.getFeatures(request):
                value = self._as_text(feature, f_table_desc)
                if value:
                    description = value
                    break
        except Exception as exc:
            _dbg(f"Table-description lookup failed: {exc}")
            description = ""

        # Cache a miss too (as an empty list), so a table with genuinely no
        # description configured is not re-queried on every keystroke.
        self._memo[key] = [AutocompleteEntry(value=description)] if description else []
        return description

    def lookup_field_description(self, field_name: str, table_candidates: Sequence[str]) -> str:
        """The Field description column's value for this field, if
        configured and found - e.g. field 'type' described as 'סוג'. Used to
        enrich the values suggestion list's title, and read mode's
        field-name annotation. Empty string when no such column is
        configured, or nothing matches.
        """
        if not field_name:
            return ""
        usable, _ = Settings.autocomplete_is_usable()
        f_field_desc = Settings.field("field_description")
        f_names = Settings.field("field_names")
        if not (usable and f_field_desc and f_names):
            return ""
        self._sync_layer_hooks()

        needle = field_name.strip().lower()
        key = (
            f"\x00field-desc:{needle}",
            "|".join(sorted(t.lower() for t in table_candidates)),
        )
        cached = self._memo.get(key)
        if cached is not None:
            return cached[0].value if cached else ""

        layer = Settings.autocomplete_layer()
        f_table = Settings.field("table")
        description = ""
        try:
            column = QgsExpression.quotedColumnRef(f_names)
            clauses = [f"lower(trim({column})) = {QgsExpression.quotedString(needle)}"]
            if f_table and table_candidates:
                tcolumn = QgsExpression.quotedColumnRef(f_table)
                ors = " OR ".join(
                    f"lower(trim({tcolumn})) = {QgsExpression.quotedString(t.lower())}"
                    for t in table_candidates
                )
                clauses.append(f"({ors})")
            request = QgsFeatureRequest().setFilterExpression(" AND ".join(clauses))
            request.setLimit(50)
            try:
                request.setFlags(QgsFeatureRequest.Flag.NoGeometry)
            except Exception:
                pass
            for feature in layer.getFeatures(request):
                value = self._as_text(feature, f_field_desc)
                if value:
                    description = value
                    break
        except Exception as exc:
            _dbg(f"Field-description lookup failed: {exc}")
            description = ""

        self._memo[key] = [AutocompleteEntry(value=description)] if description else []
        return description

    def _query(self, field_name: str, table_candidates: Sequence[str]) -> List[AutocompleteEntry]:
        """Run up to four increasingly permissive passes until one finds rows.

        Order matters: the narrowest, most correct query runs first, and each
        fallback is only reached when the previous one found nothing.

        1. exact field match + table filter   <- the intended query
        2. substring field match + table filter
        3. exact field match, no table filter
        4. substring field match, no table filter

        Passes 3 and 4 exist because a Table Field value that does not match the
        current layer used to make the popup silently fail to appear, which is
        far worse than showing slightly broader results.  When a fallback is
        used it is reported at Warning level so the misconfiguration is visible.
        Set TABLE_FILTER_FALLBACK = False to keep the filter strict.
        """
        layer = Settings.autocomplete_layer()
        if layer is None:
            return []

        f_names = Settings.field("field_names")
        f_value = Settings.field("value")
        f_table = Settings.field("table")
        f_desc = Settings.field("description")
        f_gcode = Settings.field("group_code")
        f_gdesc = Settings.field("group_description")

        try:
            available = {f.name() for f in layer.fields()}
        except Exception:
            return []

        # Silently ignore optional fields that were deleted from the layer.
        f_desc = f_desc if f_desc in available else ""
        f_gcode = f_gcode if f_gcode in available else ""
        f_gdesc = f_gdesc if f_gdesc in available else ""
        f_table = f_table if f_table in available else ""

        wanted = [n for n in (f_names, f_value, f_table, f_desc, f_gcode, f_gdesc) if n]

        # A configured Table Field with no resolvable table context used to fall
        # through to the unfiltered passes below, which returned values for
        # *every* table - indistinguishable from the filter not working. Treat an
        # unknown context as "no match" instead, so the behaviour is strict and
        # the misconfiguration is visible rather than silently wrong.
        if f_table and not table_candidates:
            _dbg(
                f"Autocomplete: Table Field '{f_table}' is configured but the "
                f"current layer's source table could not be determined; "
                f"returning no values. Run diagnose() to investigate."
            )
            return []

        filtering_by_table = bool(f_table and table_candidates)
        passes: List[Tuple[bool, bool]] = []
        if filtering_by_table:
            passes += [(True, True), (False, True)]
            if TABLE_FILTER_FALLBACK:
                passes += [(True, False), (False, False)]
        else:
            passes += [(True, False), (False, False)]

        for exact, use_table in passes:
            expression = self._expression(
                field_name,
                f_names,
                f_table if use_table else "",
                table_candidates,
                exact,
            )
            _dbg(f"Autocomplete query: {expression}")
            entries = self._run(
                layer, wanted, expression, f_value, f_desc, f_gcode, f_gdesc
            )
            if entries:
                if filtering_by_table and not use_table:
                    # Diagnostic only. This must NOT reach the message log by
                    # default: writing to it can raise the Log Messages dock,
                    # which pulls keyboard focus off a modal dialog and leaves
                    # the caret invisible until the dialog is reopened.
                    _dbg(
                        f"Autocomplete: no rows matched the table filter "
                        f"({f_table} in {list(table_candidates)}); fell back to "
                        f"all tables for field '{field_name}'."
                    )
                return entries

        _dbg(f"Autocomplete: no rows at all for field '{field_name}'.")
        return []

    @staticmethod
    def _expression(
        field_name: str,
        f_names: str,
        f_table: str,
        table_candidates: Sequence[str],
        exact: bool,
    ) -> str:
        """Build a provider-side filter expression.

        Uses QgsExpression quoting helpers throughout, so a field name or value
        containing quotes cannot break the expression.
        """
        # lower(trim(...)) on the column side: lookup tables are hand-maintained
        # and trailing spaces are a common, invisible cause of "no match".  It
        # can stop the provider from using an index, which is an acceptable
        # trade for a small configuration table capped by QUERY_LIMIT.
        col = f"lower(trim({QgsExpression.quotedColumnRef(f_names)}))"
        needle = field_name.strip().lower()
        if exact:
            clauses = [f"{col} = {QgsExpression.quotedString(needle)}"]
        else:
            clauses = [f"{col} LIKE {QgsExpression.quotedString('%' + needle + '%')}"]

        if f_table and table_candidates:
            tcol = f"lower(trim({QgsExpression.quotedColumnRef(f_table)}))"
            ors = " OR ".join(
                f"{tcol} = {QgsExpression.quotedString(t.strip().lower())}"
                for t in table_candidates
            )
            clauses.append(f"({ors})")

        return " AND ".join(clauses)

    def _run(
        self,
        layer,
        wanted: List[str],
        expression: str,
        f_value: str,
        f_desc: str,
        f_gcode: str,
        f_gdesc: str,
    ) -> List[AutocompleteEntry]:
        entries: List[AutocompleteEntry] = []
        try:
            request = QgsFeatureRequest().setFilterExpression(expression)
            request.setLimit(QUERY_LIMIT)
            try:
                request.setFlags(QgsFeatureRequest.Flag.NoGeometry)
            except Exception:
                pass
            # Deliberately NOT calling setSubsetOfAttributes(): when a filter
            # expression is evaluated client-side (which happens whenever the
            # provider cannot compile it to SQL), any column missing from the
            # subset evaluates as NULL and the row silently fails to match.
            # A lookup table is small, so fetching all attributes is cheaper
            # than that failure mode. `wanted` is kept for diagnostics.
            _ = wanted

            # Deduplicate on the whole entry, not on the value alone.
            #
            # A value is legitimately allowed to repeat under different groups or
            # with a different description - e.g. code 610 meaning 'mosque' in
            # group 2300 and 'greenhouse' in group 2301. Keying only on the value
            # discarded the second row, and where that row was a group's only
            # member the entire group disappeared from the popup.
            #
            # Using the full tuple still collapses genuinely identical rows,
            # which is all the dedup was ever meant to do.
            seen = set()
            for feature in layer.getFeatures(request):
                value = self._as_text(feature, f_value)
                if not value:
                    continue
                description = self._as_text(feature, f_desc)
                group_code = self._as_text(feature, f_gcode)
                group_description = self._as_text(feature, f_gdesc)
                key = (value, description, group_code, group_description)
                if key in seen:
                    continue
                seen.add(key)
                entries.append(
                    AutocompleteEntry(
                        value=value,
                        description=description,
                        group_code=group_code,
                        group_description=group_description,
                    )
                )
                if len(entries) >= QUERY_LIMIT:
                    break
        except Exception as exc:
            # Also diagnostic-only, for the focus reason described above.
            _dbg(f"Autocomplete query failed: {exc}")
            return []
        return entries

    @staticmethod
    def _as_text(feature, field_name: str) -> str:
        """Read a field as a trimmed string, tolerating NULLs and numerics."""
        if not field_name:
            return ""
        try:
            raw = feature[field_name]
        except Exception:
            return ""
        if raw is None:
            return ""
        try:
            if hasattr(raw, "isNull") and raw.isNull():
                return ""
        except Exception:
            pass
        return str(raw).strip()


_CACHE: Optional[AutocompleteCache] = None


def cache() -> AutocompleteCache:
    """Shared cache instance, created on first use."""
    global _CACHE
    if _CACHE is None:
        _CACHE = AutocompleteCache()
    return _CACHE


# --------------------------------------------------------------------------- #
# Popup
# --------------------------------------------------------------------------- #


class AutocompletePopup(QListWidget):
    """Grouped, non-focus-stealing completion list.

    Configured the same way ``QCompleter`` configures its own popup - a
    parentless ``Qt.Popup`` window with ``NoFocus`` and a focus proxy back to
    the editor - so the caret keeps blinking in the editor and typing continues
    to reach it while the list is open.

    Group headers are inserted as non-selectable items; navigation skips them.
    """

    def __init__(self, editor):
        super().__init__(None)
        self._editor = editor
        self.setWindowFlags(Qt.WindowType.Popup | Qt.WindowType.FramelessWindowHint)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setFocusProxy(editor)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setUniformItemSizes(False)
        self.setAlternatingRowColors(False)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        # Right-to-left values must still read correctly inside the list.
        self.setLayoutDirection(editor.layoutDirection())

    # -- population -------------------------------------------------------- #

    def populate(self, entries: Sequence[AutocompleteEntry], title: str = "") -> int:
        """Fill the list, inserting group headers when grouping is configured.

        ``title`` is an optional heading shown above everything else - the
        layer/dataset name when offering field names, or the field name when
        offering its values (see ``CustomAutocompleteController._collect_entries``)
        - so the user always knows at a glance which dataset or field the list
        belongs to. Deliberately sized larger than a group header (see
        ``_make_title``/``_make_header``) so the hierarchy reads unambiguously:
        title, then group, then value.

        Returns the number of selectable value rows.
        """
        self.clear()
        grouped = any(e.group_label for e in entries)
        selectable = 0
        current_group = None

        if title:
            self.addItem(self._make_title(title))

        for entry in entries[:MAX_DISPLAYED]:
            if grouped and entry.group_label != current_group:
                current_group = entry.group_label
                self.addItem(self._make_header(current_group or "Ungrouped"))
            item = QListWidgetItem(("    " if grouped else "") + entry.display)
            item.setData(VALUE_ROLE, entry.value)
            item.setData(DESC_ROLE, entry.description)
            item.setData(INSERT_ROLE, entry.insert_text)
            item.setData(CARET_ROLE, int(entry.caret_offset))
            tooltip = entry.help_text or entry.description
            if tooltip:
                item.setToolTip(tooltip)
            self.addItem(item)
            selectable += 1

        self._select_first_value()
        return selectable

    def show_notice(self, text: str) -> None:
        """Display a single, non-selectable explanatory line.

        Silence was the worst property of the old behaviour: a field with no
        definitions, or an unresolvable table context, produced no popup and no
        feedback, indistinguishable from the key not arriving at all. A visible
        notice makes the feature self-diagnosing without writing to the message
        log (which can raise the Log dock and steal focus from a modal dialog).
        """
        self.clear()
        item = QListWidgetItem(text)
        item.setFlags(Qt.ItemFlag.NoItemFlags)
        item.setForeground(QColor("#b7791f"))
        self.addItem(item)
        self.show_at_cursor()

    @staticmethod
    def _make_header(text: str) -> QListWidgetItem:
        item = QListWidgetItem(text)
        font = QFont(item.font())
        font.setBold(True)
        item.setFont(font)
        item.setFlags(Qt.ItemFlag.NoItemFlags)  # not selectable, not enabled
        item.setForeground(QColor("#4271ae"))
        return item

    @staticmethod
    def _make_title(text: str) -> QListWidgetItem:
        """The dataset/field heading - a little bigger and bolder than a
        group header (see ``_make_header``), so it reads as one level up in
        the hierarchy even when the list is also grouped, without dominating
        the rest of the popup."""
        item = QListWidgetItem(text)
        font = QFont(item.font())
        font.setBold(True)
        if font.pointSizeF() > 0:
            # A fractional size (setPointSizeF, not setPointSize) is what
            # makes a genuinely subtle +0.5pt step possible - the smallest
            # bump that still reads as "one level up" from a same-size bold
            # group heading without the title dominating the popup.
            font.setPointSizeF(font.pointSizeF() + 0.5)
        else:
            # Some platforms configure the base font by pixel size rather
            # than point size, in which case pointSizeF() returns -1 rather
            # than a usable number - fall back to the pixel-size equivalent
            # rather than silently leaving the title unenlarged.
            font.setPixelSize(max(1, font.pixelSize() + 1))
        item.setFont(font)
        item.setFlags(Qt.ItemFlag.NoItemFlags)  # not selectable, not enabled
        item.setForeground(QColor("#1a5276"))
        return item

    # -- navigation -------------------------------------------------------- #

    def _is_value_row(self, row: int) -> bool:
        item = self.item(row)
        return item is not None and bool(item.data(VALUE_ROLE))

    def _select_first_value(self) -> None:
        for row in range(self.count()):
            if self._is_value_row(row):
                self.setCurrentRow(row)
                return

    def move_selection(self, step: int) -> None:
        """Move by ``step`` rows, skipping group headers and wrapping around."""
        count = self.count()
        if count == 0:
            return
        row = self.currentRow()
        for _ in range(count):
            row = (row + step) % count
            if self._is_value_row(row):
                self.setCurrentRow(row)
                return

    def current_value(self) -> str:
        item = self.currentItem()
        if item is None:
            return ""
        return str(item.data(VALUE_ROLE) or "")

    # -- placement --------------------------------------------------------- #

    def show_at_cursor(self) -> None:
        """Position below the caret, kept inside the available screen area."""
        editor = self._editor
        rect = editor.cursorRect()
        point = editor.mapToGlobal(rect.bottomLeft())
        point.setY(point.y() + POPUP_VERTICAL_GAP)

        rows = min(self.count(), 12)
        height = max(60, sum(self.sizeHintForRow(r) for r in range(rows)) + 8)
        width = max(220, min(520, self.sizeHintForColumn(0) + 40))

        try:
            screen = editor.screen().availableGeometry()
            if point.y() + height > screen.bottom():
                point.setY(editor.mapToGlobal(rect.topLeft()).y() - height - POPUP_VERTICAL_GAP)
            if point.x() + width > screen.right():
                point.setX(max(screen.left(), screen.right() - width))
        except Exception:
            pass

        self.setGeometry(point.x(), point.y(), width, height)
        self.show()
        self.raise_()


# --------------------------------------------------------------------------- #
# Call tip
# --------------------------------------------------------------------------- #


class CallTipPopup(QLabel):
    """A small signature-hint popup, styled like a tooltip.

    An ordinary label rather than QToolTip so ``show_call_tip`` fully
    controls when it appears and disappears - QToolTip only ever hides
    itself on a timer or on the next mouse move, neither of which lines up
    with "the caret left the function call".
    """

    def __init__(self, editor):
        super().__init__(None)
        self._editor = editor
        self.setWindowFlags(Qt.WindowType.ToolTip | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating, True)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setTextFormat(Qt.TextFormat.RichText)
        self.setWordWrap(True)
        self.setMargin(6)
        self.setMaximumWidth(480)
        self.setStyleSheet(
            "QLabel { background-color: #ffffe1; color: #202020; "
            "border: 1px solid #b0b0b0; }"
        )

    def show_body(self, body: str, point) -> None:
        self.setText(body)
        self.adjustSize()
        self.move(point)
        self.show()
        self.raise_()

    def reposition(self, point) -> None:
        """Follow the parent window without changing what is displayed."""
        self.move(point)


# --------------------------------------------------------------------------- #
# Controller
# --------------------------------------------------------------------------- #


class CustomAutocompleteController(QObject):
    """Wires Ctrl+Space on one overlay editor to the custom source.

    Integration is intentionally minimal and reversible:

    * an event filter on the editor - so the editor's own ``keyPressEvent`` is
      untouched and its built-in function/field completer keeps working;
    * ``QTextCursor.insertText()`` for insertion - so the existing overlay ->
      Scintilla synchronisation carries the change, unchanged.

    If the feature is disabled in settings, the filter returns immediately and
    the editor behaves exactly as before.
    """

    def __init__(self, editor):
        super().__init__(editor)
        self._editor = editor
        self._popup: Optional[AutocompletePopup] = None
        self._call_tip: Optional[CallTipPopup] = None
        self._entries: List[AutocompleteEntry] = []
        self._field_name = ""
        #: True while the popup lists field names rather than values.
        self._field_mode = False
        #: True while the popup lists values (quoted literals) for a field.
        self._value_mode = False
        #: Heading shown above the popup's contents - the dataset/layer name
        #: for a field list, the field name for a values list, empty
        #: otherwise. Recomputed by ``_collect_entries`` every time the
        #: context is (re)evaluated, not on every refilter keystroke.
        self._popup_title = ""
        #: True while a key event is being re-sent to the editor, to stop the
        #: editor branch of eventFilter from re-entering the popup handler.
        self._forwarding = False
        #: True for the one cursor move right after Enter, so the call tip
        #: stays closed even though the caret may still be enclosed by the
        #: same (now multi-line) call.
        self._suppress_call_tip_once = False
        try:
            editor.installEventFilter(self)
        except Exception as exc:
            _log(f"Custom autocomplete not attached: {exc}", Qgis.MessageLevel.Warning)

        # The call tip must track the caret continuously, not just on the
        # keystrokes that used to trigger it: moving the caret out of a
        # call's parentheses (an arrow key, a mouse click, undo/redo, a field
        # inserted by a QGIS toolbar button) should close it exactly as
        # typing ')' does, and moving back in should reopen it. Both are the
        # same recomputation, so one signal covers every way the caret moves.
        try:
            editor.cursorPositionChanged.connect(self._on_cursor_moved)
        except Exception:
            pass

        # New text should offer suggestions as it is typed, the same three
        # contexts Ctrl+Space already recognises (fields, values, the full
        # grouped list) - see _auto_trigger.
        try:
            editor.textChanged.connect(self._auto_trigger_soon)
        except Exception:
            pass

        # Both popups are Qt.ToolTip windows with WA_ShowWithoutActivating, so
        # they never go through the editor's own focus-in/out cycle - neither
        # switching to a different application, nor switching to a different
        # QGIS window while this one stays open in the background, generates
        # a FocusOut on the editor. focusWindowChanged is the one signal that
        # reports a change of *OS-level* focus window, covering both cases
        # plus clicking through to the desktop (window becomes None) - so the
        # popups only ever show while this dialog is the active window.
        try:
            app = QApplication.instance()
            if app is not None:
                app.focusWindowChanged.connect(self._on_focus_window_changed)
        except Exception:
            pass

        # The call tip is glued to the caret's screen position; if the dialog
        # itself moves or resizes, that position moves with it.
        try:
            window = editor.window()
            if window is not None:
                window.installEventFilter(self)
        except Exception:
            pass

    # -- teardown ---------------------------------------------------------- #

    def teardown(self) -> None:
        """Called from the editor's detach(); safe to call more than once."""
        self.hide_popup()
        self._hide_call_tip()
        try:
            app = QApplication.instance()
            if app is not None:
                app.focusWindowChanged.disconnect(self._on_focus_window_changed)
        except Exception:
            pass
        try:
            if self._editor is not None:
                self._editor.cursorPositionChanged.disconnect(self._on_cursor_moved)
        except Exception:
            pass
        try:
            if self._editor is not None:
                self._editor.textChanged.disconnect(self._auto_trigger_soon)
        except Exception:
            pass
        try:
            if self._editor is not None:
                window = self._editor.window()
                if window is not None:
                    window.removeEventFilter(self)
        except Exception:
            pass
        try:
            if self._editor is not None:
                self._editor.removeEventFilter(self)
        except Exception:
            pass
        if self._popup is not None:
            try:
                self._popup.removeEventFilter(self)
            except Exception:
                pass
            try:
                self._popup.deleteLater()
            except Exception:
                pass
            self._popup = None
        if self._call_tip is not None:
            try:
                self._call_tip.deleteLater()
            except Exception:
                pass
            self._call_tip = None
        self._editor = None

    # -- event handling ---------------------------------------------------- #

    def eventFilter(self, obj, event) -> bool:  # noqa: N802 (Qt override)
        """Filter both the editor and the popup.

        The popup is a ``Qt.Popup`` window, and Qt gives such a window a
        keyboard *and* mouse grab.  Filtering only the editor therefore never
        sees Escape or the arrow keys while the list is open, and never sees a
        click landing outside it.  Both targets are filtered here, which is what
        ``QCompleter`` does internally for the same reason.
        """
        try:
            event_type = event.type()
            popup = self._popup

            # --- popup is open: it owns the keyboard and mouse grabs ------- #
            if popup is not None and obj is popup:
                if event_type == QEvent.Type.ShortcutOverride and event.key() == Qt.Key.Key_Escape:
                    # The popup declines focus (see AutocompletePopup.__init__,
                    # setFocusPolicy(NoFocus) + setFocusProxy(editor)), so it is
                    # not certain whether Qt routes Escape's ShortcutOverride to
                    # the popup itself or to the editor it proxies to - claim it
                    # on whichever object actually gets it, so a dialog-level
                    # Escape shortcut never wins the race against the KeyPress
                    # that follows.
                    event.accept()
                    return True
                if event_type == QEvent.Type.KeyPress:
                    return self._on_popup_key(event)
                if event_type in (
                    QEvent.Type.MouseButtonPress,
                    QEvent.Type.MouseButtonDblClick,
                ):
                    if not self._event_inside_popup(event):
                        # A click outside dismisses, exactly like a menu.
                        self.hide_popup()
                        return True
                    return False
                # Deliberately NOT hiding on the popup's own WindowDeactivate/
                # FocusOut: several Linux window managers deliver one to a
                # freshly-mapped Qt.Popup window before they have actually
                # finished activating it, which hid the popup within a
                # millisecond of it appearing - it would flash and vanish
                # before it could ever be read, let alone used. Every genuine
                # reason to close it is already covered elsewhere:
                # _on_focus_window_changed for switching to a different
                # window or application, the editor's own FocusOut handling
                # below for focus genuinely leaving the editor, and Escape /
                # click-outside / accepting a value for everything else.
                return False

            # --- editor ---------------------------------------------------- #
            if obj is self._editor:
                # Claim the trigger before Qt's shortcut machinery does.
                #
                # If any QAction anywhere in the window chain is bound to our
                # trigger combination, Qt sends ShortcutOverride first; if nobody
                # accepts it, the QAction fires and NO KeyPress is ever delivered
                # to the widget. Accepting the override tells Qt "this widget
                # will handle the key itself", after which the normal KeyPress
                # arrives and the branch below runs. Without this, Ctrl+Space can
                # silently do nothing with no way to tell why.
                if event_type == QEvent.Type.ShortcutOverride and (
                    self._is_trigger(event) or self._is_diagnostic(event)
                ):
                    event.accept()
                    return True
                if (
                    event_type == QEvent.Type.ShortcutOverride
                    and event.key() == Qt.Key.Key_Escape
                    and popup is not None
                    and popup.isVisible()
                ):
                    # The popup declines focus and proxies it back to the
                    # editor (see AutocompletePopup.__init__), so Qt still
                    # sends ShortcutOverride to the editor even though the
                    # popup's own keyboard grab is what actually delivers the
                    # following KeyPress. If the dialog has an Escape
                    # QShortcut of its own (many QDialogs do, for "close on
                    # Escape"), it fires right here - before the grab ever
                    # gets a say - and closes the dialog instead of the list.
                    # Claiming the override keeps that from happening; the
                    # KeyPress that follows is handled below as usual.
                    event.accept()
                    return True
                if event_type == QEvent.Type.KeyPress and not self._forwarding:
                    if popup is not None and popup.isVisible():
                        # Keys normally reach the popup; if one arrives here
                        # anyway, handle it identically.
                        return self._on_popup_key(event)
                    if self._is_diagnostic(event):
                        self._show_report()
                        return True
                    if self._is_trigger(event):
                        self.trigger()
                        return True
                    # Enter always closes the call tip, matching QGIS's own
                    # function helper - even though the caret may still be
                    # enclosed by the same call once Enter inserts a newline
                    # (multi-line calls are legal). cursorPositionChanged
                    # (see _on_cursor_moved) is what actually shows/hides the
                    # tip as the caret moves - including in and out of a call
                    # via '(', ',' and ')' - so this only needs to mark the
                    # one recomputation right after Enter as an exception.
                    #
                    # Escape is deliberately NOT used to dismiss the call tip:
                    # unlike the completion popup (a real Qt.Popup with its
                    # own keyboard grab), the plain editor never gets a
                    # KeyPress for Escape to filter in the first place - the
                    # dialog's own Escape-closes-the-dialog shortcut claims it
                    # first, at the ShortcutOverride stage. Consuming it here
                    # would be a no-op at best and confusing at worst.
                    if event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                        self._suppress_call_tip_once = True
                elif event_type == QEvent.Type.FocusOut:
                    # Showing a Qt.Popup window takes the keyboard grab, which
                    # makes Qt deliver FocusOut to the editor with reason
                    # PopupFocusReason. Treating that as "user looked away" would
                    # hide the list in the same instant it appears - the popup
                    # would flash, or never seem to open at all. Only a genuine
                    # focus change ends the session.
                    try:
                        reason = event.reason()
                        transient = reason in (
                            Qt.FocusReason.PopupFocusReason,
                            Qt.FocusReason.ActiveWindowFocusReason,
                        )
                    except Exception:
                        transient = False
                    if not transient:
                        self.hide_popup()
                        self._hide_call_tip()
                elif event_type in (
                    QEvent.Type.Wheel,
                    QEvent.Type.Hide,
                ):
                    # Scrolling or the dialog closing leaves a floating list stale.
                    self.hide_popup()
                    self._hide_call_tip()
                return False

            # --- the dialog itself: keep the call tip glued to the caret --- #
            if event_type in (QEvent.Type.Move, QEvent.Type.Resize):
                self._reposition_call_tip()
        except Exception as exc:
            _log(f"Custom autocomplete error: {exc}", Qgis.MessageLevel.Warning)
        return False

    def _on_focus_window_changed(self, window) -> None:
        """Hide both popups the moment a different top-level window is active.

        Covers switching to another application, switching to a different
        QGIS window or dialog while this one stays open behind it, and
        clicking through to the desktop (``window`` is then ``None``) - so
        the popups are visible only while this specific dialog (Expression
        Builder, Field Calculator, Layer Filter, ...) is the active window.
        """
        editor = self._editor
        if editor is None:
            return
        try:
            own_window = editor.window().windowHandle()
        except Exception:
            own_window = None
        if own_window is None:
            # Could not resolve our own window - nothing safe to compare
            # against, so err on the side of not hiding anything.
            return
        if window is own_window:
            return
        self.hide_popup()
        self._hide_call_tip()

    def _event_inside_popup(self, event) -> bool:
        """True when a mouse event landed within the popup's own rectangle."""
        if self._popup is None:
            return False
        try:
            try:
                point = event.globalPosition().toPoint()  # Qt6
            except AttributeError:
                point = event.globalPos()  # Qt5 fallback
            return self._popup.geometry().contains(point)
        except Exception:
            return True  # when in doubt, do not dismiss

    @staticmethod
    def _is_trigger(event) -> bool:
        """True for any of the accepted trigger combinations.

        Three combinations are accepted because Ctrl+Space is not dependable on
        every system:

        * **Ctrl+Space** - the documented default.
        * **Ctrl+Shift+Space** - distinguishes an OS-level grab from a plugin
          problem. On Windows, Ctrl+Space toggles input method modes for several
          keyboard layouts (Hebrew among them), in which case the key never
          reaches Qt at all and no amount of event filtering can see it.
        * **Ctrl+J** - a plain fallback that no input method claims. If this
          works and Ctrl+Space does not, the OS or the IME is the culprit.
        """
        if not (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
            return False
        return event.key() in (
            Qt.Key.Key_Space,
            Qt.Key.Key_nobreakspace,
            Qt.Key.Key_J,
        )

    @staticmethod
    def _is_diagnostic(event) -> bool:
        """Ctrl+Shift+D - show the diagnostic report in a message box.

        Needed because the Layer Filter and Field Calculator are **modal**
        dialogs: while one is open the Python Console cannot be used at all, so
        diagnose() and force_complete() are unreachable exactly when the problem
        is happening. A QMessageBox opens on top of a modal dialog, so this
        works where console-based diagnostics cannot.
        """
        modifiers = event.modifiers()
        return (
            bool(modifiers & Qt.KeyboardModifier.ControlModifier)
            and bool(modifiers & Qt.KeyboardModifier.ShiftModifier)
            and event.key() == Qt.Key.Key_D
        )

    def _report_text(self) -> str:
        """Build the same information diagnose() prints, as a single string."""
        lines = []
        editor = self._editor
        lines.append(f"module: {__file__}")
        lines.append(f"controller attached: yes ({type(self).__name__})")

        usable, reason = Settings.autocomplete_is_usable()
        lines.append(f"configuration usable: {usable}" + ("" if usable else f" ({reason})"))

        layer = Settings.autocomplete_layer()
        lines.append(f"lookup layer: {layer.name() if layer is not None else None}")
        if layer is not None:
            try:
                lines.append(f"lookup rows: {layer.featureCount()}")
            except Exception:
                pass

        if editor is None:
            lines.append("editor: GONE")
            return "\n".join(lines)

        text_before = editor.toPlainText()[: editor.textCursor().position()]
        field_name = detect_field_name(text_before)
        lines.append(f"text before caret: {text_before[-60:]!r}")
        lines.append(f"detected field: {field_name!r}")

        sci = getattr(editor, "_sci", None)
        context = _find_context_layer(sci if sci is not None else editor)
        lines.append(f"context layer: {context.name() if context is not None else None}")
        if context is not None:
            lines.append(f"context provider: {context.providerType()}")
            lines.append(f"source table: {source_table_name(context)!r}")
        candidates = resolve_table_candidates(sci if sci is not None else editor)
        lines.append(f"table candidates: {candidates}")

        # This must DIFFER between two expression slots (e.g. fill colour vs
        # stroke colour). If it is identical, their remembered choices collide.
        try:
            from .rtl_readmode import expression_context_key

            lines.append(f"context key: {expression_context_key(sci if sci is not None else editor)!r}")
        except Exception as exc:
            lines.append(f"context key: FAILED {exc!r}")

        if usable and field_name:
            try:
                entries = cache().lookup(field_name, candidates)
                lines.append(f"rows found: {len(entries)}")
                if entries:
                    lines.append(
                        "sample: " + ", ".join(e.display for e in entries[:5])
                    )
            except Exception as exc:
                lines.append(f"lookup raised: {exc}")

        return "\n".join(lines)

    def _show_report(self) -> None:
        """Display the report over the modal dialog."""
        from qgis.PyQt.QtWidgets import QMessageBox

        try:
            text = self._report_text()
        except Exception as exc:
            text = f"report failed: {exc}"
        try:
            box = QMessageBox(self._editor)
            box.setWindowTitle("RTL autocomplete - diagnostic")
            box.setIcon(QMessageBox.Icon.Information)
            box.setText("Ctrl+Space diagnostic")
            box.setDetailedText(text)
            box.setStandardButtons(QMessageBox.StandardButton.Ok)
            box.exec()
        except Exception:
            pass
        # Then run the real completion. Ctrl+Shift+D is known to reach the
        # editor, so if the popup appears now but Ctrl+Space does nothing, the
        # key is being intercepted before Qt rather than the feature being
        # broken. This makes one keypress test the entire path.
        try:
            self.trigger()
        except Exception:
            pass

    def _on_popup_key(self, event) -> bool:
        """Handle a key while the list is open.  Returns True if consumed.

        Keys we do not use are forwarded to the editor, so typing keeps working
        and narrows the list; the list is then refiltered.
        """
        key = event.key()

        if key == Qt.Key.Key_Escape:
            self.hide_popup()
            self._hide_call_tip()
            return True
        if key == Qt.Key.Key_Down:
            self._popup.move_selection(1)
            return True
        if key == Qt.Key.Key_Up:
            self._popup.move_selection(-1)
            return True
        if key == Qt.Key.Key_PageDown:
            self._popup.move_selection(5)
            return True
        if key == Qt.Key.Key_PageUp:
            self._popup.move_selection(-5)
            return True
        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter, Qt.Key.Key_Tab):
            self.accept_current()
            return True
        if key in (Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Home, Qt.Key.Key_End):
            # Caret navigation ends the completion session.
            self.hide_popup()
            self._forward_to_editor(event)
            return True
        if key in (Qt.Key.Key_Backspace, Qt.Key.Key_Delete):
            # Still editing the token itself: keep narrowing/widening.
            self._forward_to_editor(event)
            self._refilter_soon()
            return True

        text = event.text()
        if text and not _CONTINUATION_CHAR_RE.match(text):
            # A boundary character - space, punctuation, an operator, the
            # closing quote - ends the token, so the list closes immediately
            # rather than waiting to find nothing matches. Matches QGIS's own
            # suggestion list, which closes on anything but Up/Down/PgUp/PgDn
            # unless it still narrows to a result.
            self.hide_popup()
            self._forward_to_editor(event)
            return True

        # A word character narrowing the token (or a key with no text, e.g. a
        # lone modifier press): let the editor apply it, then refilter -
        # narrows the list, or hides it once nothing matches any more.
        self._forward_to_editor(event)
        self._refilter_soon()
        return True

    def _forward_to_editor(self, event) -> None:
        """Re-send a key event to the editor.

        ``_forwarding`` stops the editor branch of eventFilter from seeing the
        forwarded event and looping back into the popup handler.
        """
        if self._editor is None:
            return
        self._forwarding = True
        try:
            QApplication.sendEvent(self._editor, event)
        except Exception:
            pass
        finally:
            self._forwarding = False

    def _refilter_soon(self) -> None:
        """Refilter after the editor has applied the keystroke.

        A zero-delay single shot, not a timer loop: it just defers to the end of
        the current event cycle so ``_current_token()`` sees the new text.
        """
        from qgis.PyQt.QtCore import QTimer

        QTimer.singleShot(0, self._refilter)

    # -- the feature ------------------------------------------------------- #

    def trigger(self, auto: bool = False) -> None:
        """Ctrl+Space (or automatically, while typing): show the popup.

        Works with no configuration at all: fields, functions, variables and
        operators are always available. A lookup table configured in Settings
        only narrows and enriches the field-name and value lists; it is never
        required for the feature to be active.

        ``auto`` is True when this came from typing rather than Ctrl+Space
        (see ``_auto_trigger``): the explanatory "Nothing to suggest here"
        notice is worth showing for a deliberate Ctrl+Space press that turned
        up nothing, but would be pure noise appearing on its own as the user
        types past a context with nothing to offer.
        """
        editor = self._editor
        if editor is None:
            return

        text_before = editor.toPlainText()[: editor.textCursor().position()]
        sci = getattr(editor, "_sci", None)
        probe = sci if sci is not None else editor

        kind = suggestion_context(text_before)
        self._field_mode = kind == "fields"
        self._value_mode = kind == "values"
        self._entries = self._collect_entries(kind, text_before, probe)

        if not self._entries:
            if not auto:
                self._notice("Nothing to suggest here")
            return

        self._refilter(show=True)

    def _auto_trigger_soon(self) -> None:
        """Open the suggestion list automatically as the user types.

        Deferred to the end of the event loop turn, the same way
        ``_refilter_soon`` is, so the just-typed character is already in the
        document and the caret already moved by the time the context is
        evaluated. Skipped while a key is being forwarded to the editor by
        the popup itself (``_on_popup_key``/``_refilter_soon`` already own
        that keystroke) to avoid doing the same work twice.
        """
        if self._forwarding:
            return
        from qgis.PyQt.QtCore import QTimer

        QTimer.singleShot(0, self._auto_trigger)

    def _auto_trigger(self) -> None:
        editor = self._editor
        if editor is None:
            return
        if self._popup is not None and self._popup.isVisible():
            # Already open; typing narrows or closes it through the normal
            # key handling instead.
            return
        try:
            cursor = editor.textCursor()
            if cursor.hasSelection():
                return
            text = editor.toPlainText()
            position = cursor.position()
            if self._inside_active_call(text, position):
                # Mid-argument inside an open call, on the same line as its
                # '(': the call tip already covers this position (see
                # show_call_tip), and QGIS's own editor holds off on
                # suggestions here too. Typing ')' or moving to a new line
                # needs no special case - both simply make this check false
                # the next time it runs, since the caret is then either
                # outside the call or past a newline within it.
                return
            text_before = text[:position]
            kind = suggestion_context(text_before)
            if kind == "mixed" and not self._current_token():
                # Fields and values are anchored to a delimiter the user just
                # typed ('"' or "'"), so showing them immediately makes sense
                # even with nothing typed yet. The full function/variable/
                # operator list has no such anchor - opening it on every
                # keystroke that is not building a word (a space, an
                # operator, a digit with no prefix) would be far too noisy,
                # so it waits for an actual prefix to narrow it by.
                return
            self.trigger(auto=True)
        except Exception as exc:
            _dbg(f"Auto-trigger failed: {exc}")

    def _inside_active_call(self, text: str, position: int) -> bool:
        """True while the caret is mid-argument inside an open function call.

        "Mid-argument" specifically: enclosed by an unclosed '(', and still on
        the same source line as that '(' - typing ')' or Enter both end this
        state, closing the call in the first case and starting a fresh line
        within it in the second, matching how QGIS's own editor behaves.
        """
        name, open_index = self._enclosing_function(text, position)
        if not name:
            return False
        return "\n" not in text[open_index:position]

    def _collect_entries(self, kind: str, text_before: str, probe) -> List[AutocompleteEntry]:
        """Build the entry list for this context. One rule per context:

        * ``"fields"``    - field names from the configured lookup table if
          one is set, otherwise the current layer's own fields.
        * ``"values"``    - values for the field just named, from the lookup
          table if configured (grouped by the group field, when set),
          otherwise the field's own first N non-null values (N from Settings).
        * ``"variables"`` - variable names.
        * anything else   - the full list of functions, variables and
          operators, grouped exactly as the Expression Builder groups them.

        None of this needs a configured lookup table - it is only ever used
        to narrow and enrich the fields/values lists when one is present, so
        Ctrl+Space works the same on a project where nothing has been set up.
        """
        try:
            layer = _find_context_layer(probe)
        except Exception:
            layer = None

        usable, _ = Settings.autocomplete_is_usable()
        tables = resolve_table_candidates(probe) if usable else []

        if kind == "fields":
            # Naming a field: the title is WHICH dataset/layer its fields
            # belong to, so a user working across several layers is never in
            # doubt about which one this list describes. Enriched with the
            # dataset's own Table description column, e.g. "buildings (מבנים)".
            name = self._layer_display_name(layer)
            description = cache().lookup_table_description(tables) if usable else ""
            self._popup_title = f"{name} ({description})" if name and description else name
            return self._field_entries(layer, usable, tables)
        if kind == "values":
            # Typing a value: the title is WHICH field it belongs to. Set to
            # "" up front so a field that turns out to have nothing to offer
            # never carries over a stale title from a previous, unrelated
            # popup.
            self._popup_title = ""
            entries = self._value_entries(text_before, layer, usable, tables)
            if entries:
                field = self._field_name
                description = cache().lookup_field_description(field, tables) if usable else ""
                self._popup_title = f"{field} ({description})" if field and description else field
            return entries
        if kind == "variables":
            self._popup_title = ""
            return self._variable_entries(layer)
        self._popup_title = ""
        return self._full_entries(layer)

    @staticmethod
    def _layer_display_name(layer) -> str:
        """The name shown as the fields list's title.

        ``layer.name()`` is the same label the Layers panel shows, so it is
        what the user already recognises - falls back to the underlying
        source table name on the rare layer that reports no name at all.
        """
        if layer is None:
            return ""
        try:
            name = layer.name()
            if name:
                return name
        except Exception:
            pass
        try:
            return source_table_name(layer)
        except Exception:
            return ""

    @staticmethod
    def _field_entries(layer, usable: bool, tables: Sequence[str]) -> List[AutocompleteEntry]:
        """Field names: the configured lookup table if set, else the layer's.

        Each entry's own Field description, when configured, is shown next
        to its name, e.g. "type (סוג)" - the same enrichment already used for
        the list's title, just per-row here.
        """
        names: List[str] = []
        descriptions: Dict[str, str] = {}
        if usable:
            try:
                names = cache().lookup_field_names(tables)
                descriptions = cache().lookup_field_descriptions(tables)
            except Exception as exc:
                _dbg(f"Field-name lookup failed: {exc}")
        if not names:
            names = context_field_names(layer)
        return [
            AutocompleteEntry(
                value=f'"{name}"',
                group_code=GROUP_FIELDS,
                display_text=(
                    f"{name} ({descriptions[name.lower()]})"
                    if name.lower() in descriptions
                    else name
                ),
                insert_text=f'"{name}"',
            )
            for name in names
        ]

    def _value_entries(
        self, text_before: str, layer, usable: bool, tables: Sequence[str]
    ) -> List[AutocompleteEntry]:
        """Values for the field before the caret: lookup table, else the layer."""
        field_name = detect_field_name(text_before)
        if not field_name:
            return []
        self._field_name = field_name

        if usable:
            try:
                found = cache().lookup(field_name, tables)
            except Exception as exc:
                _dbg(f"Value lookup failed: {exc}")
                found = []
            if found:
                entries = []
                for entry in found:
                    if not entry.group_code and not entry.group_description:
                        entry.group_code = GROUP_VALUES
                    entries.append(entry)
                return entries

        # No configured table, or nothing in it for this field: fall back to
        # the first few distinct, non-null values already in the layer.
        limit = Settings.max_suggested_values()
        return [
            AutocompleteEntry(value=v, group_code=GROUP_VALUES)
            for v in layer_first_values(layer, field_name, limit)
        ]

    @staticmethod
    def _variable_entries(layer) -> List[AutocompleteEntry]:
        return [
            AutocompleteEntry(
                value=f"@{name}",
                group_code=GROUP_VARIABLES,
                display_text=f"@{name}",
                insert_text=f"@{name}",
            )
            for name in builtin_variables(layer)
        ]

    @staticmethod
    def _full_entries(layer) -> List[AutocompleteEntry]:
        """Everything that is not a field or a value.

        Grouped exactly like the Expression Builder's own tree: each function
        under its real category (Aggregates, Arrays, Color, Conditionals,
        Geometry, Operators, ...), reported by QgsExpression itself, plus
        Variables and Operators as their own groups.
        """
        entries: List[AutocompleteEntry] = list(
            CustomAutocompleteController._variable_entries(layer)
        )

        for name, _signature, help_html, param_count, group, _params in builtin_functions():
            entries.append(
                AutocompleteEntry(
                    value=name,
                    group_code=group,
                    # Name only, per spec - the signature still shows up in
                    # the tooltip and in the call tip after insertion.
                    display_text=name,
                    insert_text=f"{name}()",
                    help_text=help_html,
                    # Land the caret between the parentheses when the
                    # function takes arguments; after them when it does not.
                    caret_offset=1 if param_count else 0,
                )
            )

        for token in _OPERATORS:
            entries.append(
                AutocompleteEntry(value=token, group_code=GROUP_OPERATORS, display_text=token)
            )

        entries.sort(key=lambda e: (e.group_label.lower(), e.display.lower()))
        return entries

    def _offer_field_names(self) -> None:
        """Populate the popup with field names rather than values."""
        editor = self._editor
        sci = getattr(editor, "_sci", None)
        tables = resolve_table_candidates(sci if sci is not None else editor)

        try:
            names = cache().lookup_field_names(tables)
        except Exception as exc:
            _dbg(f"Field-name lookup raised: {exc}")
            names = []

        if not names:
            self._notice(
                "No field names defined"
                + (f" for table '{tables[0]}'" if tables else "")
            )
            return

        self._field_mode = True
        self._entries = [AutocompleteEntry(value=n) for n in names]
        self._refilter(show=True)

    def _notice(self, text: str) -> None:
        """Show a transient explanatory popup instead of failing silently."""
        try:
            if self._popup is None:
                self._popup = AutocompletePopup(self._editor)
                self._popup.itemClicked.connect(lambda _i: self.accept_current())
                self._popup.installEventFilter(self)
            self._entries = []
            self._popup.show_notice(text)
        except Exception:
            pass

    def _restore_caret(self) -> None:
        """Force the caret to repaint, without touching focus.

        Re-applying the text cursor makes QPlainTextEdit re-render and restart
        the caret blink.  Deliberately does *not* call setFocus(): this is
        reached from the editor's own FocusOut handling, and calling setFocus()
        while a FocusOut is being processed can leave Qt with no focused widget
        at all - which is itself a way to lose the caret.

        Re-applying an unchanged cursor emits cursorPositionChanged, which the
        existing synchronisation handles as a no-op push of the same position.
        No document modification occurs.
        """
        editor = self._editor
        if editor is None:
            return
        try:
            editor.setTextCursor(editor.textCursor())
            editor.ensureCursorVisible()
            editor.viewport().update()
        except Exception:
            pass

    def _current_token(self) -> str:
        """The partial value already typed immediately before the caret."""
        editor = self._editor
        if editor is None:
            return ""
        cursor = editor.textCursor()
        line = cursor.block().text()[: cursor.positionInBlock()]
        match = _TOKEN_RE.search(line)
        return match.group(0) if match else ""

    def _refilter(self, show: bool = False) -> None:
        """Apply the typed prefix and repopulate, hiding when nothing matches."""
        if self._editor is None or not self._entries:
            return
        token = self._current_token().lower()
        if token:
            subset = [
                e
                for e in self._entries
                if _unquote_for_display(e.value).lower().startswith(token)
            ]
            if not subset:
                subset = [
                    e
                    for e in self._entries
                    if token in e.filter_text.lower()
                ]
        else:
            subset = list(self._entries)

        if not subset:
            self.hide_popup()
            return

        if self._popup is None:
            self._popup = AutocompletePopup(self._editor)
            self._popup.itemClicked.connect(lambda _i: self.accept_current())
            # Filter the popup as well as the editor: as a Qt.Popup window it
            # holds the keyboard and mouse grabs (see eventFilter).
            self._popup.installEventFilter(self)
        self._popup.populate(subset, self._popup_title)
        if show or self._popup.isVisible():
            self._popup.show_at_cursor()

    def accept_current(self) -> None:
        """Insert the selected value - only the value, never the description."""
        if self._popup is None:
            return
        value = self._popup.current_value()
        insert_text = value
        caret_offset = 0
        try:
            item = self._popup.currentItem()
            if item is not None:
                insert_text = str(item.data(INSERT_ROLE) or value)
                caret_offset = int(item.data(CARET_ROLE) or 0)
        except Exception:
            pass
        chosen_description = ""
        try:
            item = self._popup.currentItem()
            if item is not None:
                chosen_description = str(item.data(DESC_ROLE) or "")
        except Exception:
            pass
        self.hide_popup()
        if not value or self._editor is None:
            return

        # A choice is about to be remembered for this expression (see
        # below) - make sure it carries its own expression-identity id
        # BEFORE any offset below is computed, so everything downstream
        # already accounts for a newly inserted id comment's length. An
        # expression nobody ever picks a described value from never gets
        # tagged with an id it would have no use for.
        eid = ""
        if not self._field_mode and chosen_description:
            eid = self._ensure_eid()

        # Replace the partial token, then insert.  This is a normal document
        # edit, so the existing overlay -> Scintilla synchronisation picks it up
        # through textChanged like any keystroke would.
        editor = self._editor
        token_len = len(self._current_token())
        text = editor.toPlainText()
        caret_pos = editor.textCursor().position()

        # _current_token() only matches word characters, so it never includes
        # the quote the user typed to open the token - e.g. after typing
        # `"N`, the token is just "N". That opening quote is always consumed
        # along with it when one is found, for either of two reasons:
        #
        # * a field entry supplies its own matching pair of quotes, so
        #   leaving the old one behind would duplicate it: `""NAME"` instead
        #   of `"NAME"`.
        # * a numeric value's insert_text has no quotes at all (bare digits
        #   need none), so the user's own opening quote would otherwise be
        #   left dangling: `'605` instead of `605`.
        quote_char = '"' if self._field_mode else ("'" if self._value_mode else None)
        remove_len = token_len
        quote_start = caret_pos - token_len - 1
        if quote_char and quote_start >= 0 and text[quote_start] == quote_char:
            remove_len += 1

        # Close the quote for the user unless one is already sitting to the
        # right of the caret - the same courtesy every editor extends when
        # completing a bracketed or quoted token.
        if quote_char and insert_text.endswith(quote_char):
            after = text[caret_pos:caret_pos + 1]
            if after == quote_char:
                insert_text = insert_text[:-1]

        cursor = editor.textCursor()
        cursor.beginEditBlock()
        if remove_len:
            cursor.movePosition(
                QTextCursor.MoveOperation.Left,
                QTextCursor.MoveMode.KeepAnchor,
                remove_len,
            )
        cursor.insertText(insert_text)
        cursor.endEditBlock()
        if caret_offset:
            cursor.movePosition(
                QTextCursor.MoveOperation.Left,
                QTextCursor.MoveMode.MoveAnchor,
                caret_offset,
            )
        self._editor.setTextCursor(cursor)

        # A function was just completed - show its signature immediately.
        if caret_offset:
            self._call_tip_soon()

        # Record which meaning was chosen, so read mode can resolve a code that
        # has several. Stores the choice, not a copy of the expression - see
        # ChoiceMemory for why that distinction matters.
        if not self._field_mode and chosen_description:
            try:
                from .rtl_readmode import (
                    ChoiceMemory,
                    expression_context_key,
                    occurrence_index,
                )

                sci = getattr(self._editor, "_sci", None)
                tables = resolve_table_candidates(sci if sci is not None else self._editor)

                # Identify WHICH occurrence of this code we just inserted, so a
                # value the user typed by hand keeps showing every meaning while
                # this one resolves to the description they picked. Count over
                # the text up to the insertion point, excluding the partial
                # token we replaced - otherwise that fragment would be counted
                # as an earlier literal and shift the index.
                cursor_position = self._editor.textCursor().position()
                insertion_start = max(0, cursor_position - len(value))
                text_before = self._editor.toPlainText()[:insertion_start]
                index = occurrence_index(text_before, self._field_name, value)

                # Scope the choice to THIS expression slot, so a fill-colour
                # override and a stroke-colour override on the same layer keep
                # separate descriptions instead of overwriting each other.
                context = expression_context_key(sci if sci is not None else self._editor)

                ChoiceMemory.remember(
                    tables[0] if tables else "",
                    self._field_name,
                    value,
                    chosen_description,
                    index,
                    context,
                    eid=eid,
                )
            except Exception as exc:
                _dbg(f"Could not remember choice: {exc}")

    def _ensure_eid(self) -> str:
        """The current document's expression-identity id, inserting one -
        as a hidden first line, see ``RtlOverlayEditor.
        hide_expression_identity_line()`` - if it does not have one yet.

        Called only right before a choice is about to be remembered (see
        ``accept_current()``), so an expression nobody ever picks a
        described value from is never tagged with an id at all.

        Never tags a layer FILTER's own expression, specifically: its text
        can be evaluated as the provider's own native SQL rather than
        QGIS's expression engine, and at least one mainstream provider
        (OGR - Shapefile, GeoJSON, ...) rejects a leading comment outright,
        confirmed directly: ``setSubsetString()`` simply returns ``False``
        and silently leaves the filter unchanged. clear_and_scan() already
        has a precise, comment-free way to verify a layer filter choice
        (the layer's own ``subsetString()`` directly) - this only ever
        tags everything else (data-defined overrides, rule-based renderer
        or labeling filters, label expressions, ...), all evaluated by
        QGIS's own expression engine, confirmed tolerant of both comment
        styles.
        """
        editor = self._editor
        if editor is None:
            return ""
        try:
            from .rtl_readmode import (
                ChoiceMemory,
                expression_context_key,
                extract_eid,
                make_eid_comment,
                new_eid,
            )

            sci = getattr(editor, "_sci", None)
            context = expression_context_key(sci if sci is not None else editor)
            if context.split("|", 1)[0] in ChoiceMemory._LAYER_FILTER_CONTEXT_MARKERS:
                return ""

            existing = extract_eid(editor.toPlainText())
            if existing:
                return existing

            eid = new_eid()
            comment = make_eid_comment(eid)
            saved_cursor = editor.textCursor()
            saved_position = saved_cursor.position()

            insert_cursor = QTextCursor(editor.document())
            insert_cursor.beginEditBlock()
            insert_cursor.setPosition(0)
            insert_cursor.insertText(comment)
            insert_cursor.endEditBlock()

            # The insertion shifted every later offset by the comment's own
            # length - restore the caret's LOGICAL position, not its
            # stale, pre-insertion numeric one.
            restored = editor.textCursor()
            restored.setPosition(saved_position + len(comment))
            editor.setTextCursor(restored)

            hide = getattr(editor, "hide_expression_identity_line", None)
            if callable(hide):
                hide()
            return eid
        except Exception as exc:
            _dbg(f"Could not ensure expression id: {exc}")
            return ""

    def _call_tip_soon(self) -> None:
        """Show the call tip after the document has settled."""
        from qgis.PyQt.QtCore import QTimer

        QTimer.singleShot(0, self.show_call_tip)

    def _on_cursor_moved(self) -> None:
        """Keep the call tip in sync with wherever the caret now is.

        Fires on every caret move for any reason at all - typing '(', ',' or
        ')', the arrow keys, a mouse click, undo/redo, a field or function a
        QGIS toolbar button inserted - so the tip opens the moment the caret
        sits inside a call's parentheses and closes the moment it does not,
        without needing to special-case each way the caret can move there.
        """
        if self._suppress_call_tip_once:
            self._suppress_call_tip_once = False
            self._hide_call_tip()
            return
        self.show_call_tip()

    def show_call_tip(self) -> None:
        """Signature hint for the function enclosing the caret.

        Our own popup rather than Scintilla's call tip, which has the same
        limitation as its completion list: it needs Scintilla to own the input
        loop. Just the name and its arguments - no help text - with the
        argument the caret is currently sitting in shown in bold.
        """
        editor = self._editor
        if editor is None:
            return
        try:
            text = editor.toPlainText()
            position = editor.textCursor().position()
            name, open_index = self._enclosing_function(text, position)
            if not name:
                self._hide_call_tip()
                return

            for func_name, _signature, _help_html, _count, _group, params in builtin_functions():
                if func_name.lower() != name.lower():
                    continue
                arg_index = self._argument_index(text, open_index, position)
                if params and arg_index >= len(params):
                    # Matches QGIS's own function helper: another comma typed
                    # past the last declared argument closes it rather than
                    # leaving nothing sensible highlighted.
                    self._hide_call_tip()
                    return

                body = self._signature_html(name, params, arg_index)
                point = self._call_tip_point()
                if self._call_tip is None:
                    self._call_tip = CallTipPopup(editor)
                self._call_tip.show_body(body, point)
                return
            self._hide_call_tip()
        except Exception as exc:
            _dbg(f"Call tip failed: {exc}")

    def _call_tip_point(self):
        """Global position for the call tip: below the caret, with a gap."""
        editor = self._editor
        point = editor.mapToGlobal(editor.cursorRect().bottomLeft())
        point.setY(point.y() + POPUP_VERTICAL_GAP)
        return point

    def _reposition_call_tip(self) -> None:
        """Keep the call tip glued to the caret when the window itself moves.

        Repositioning rather than recomputing content: a window move or
        resize does not change what the caret is enclosed by, only where that
        position now is on screen.
        """
        if self._call_tip is not None and self._call_tip.isVisible() and self._editor is not None:
            try:
                self._call_tip.reposition(self._call_tip_point())
            except Exception:
                pass

    def _hide_call_tip(self) -> None:
        if self._call_tip is not None:
            try:
                self._call_tip.hide()
            except Exception:
                pass

    @staticmethod
    def _enclosing_function(text: str, position: int) -> Tuple[str, int]:
        """``(name, open_paren_index)`` of the call enclosing ``position``.

        Walks backwards counting bracket depth, so a nested call reports the
        innermost function - the one the caret is actually inside. Returns
        ``("", -1)`` when the caret is not inside any call.
        """
        depth = 0
        index = position - 1
        while index >= 0:
            char = text[index]
            if char == ")":
                depth += 1
            elif char == "(":
                if depth == 0:
                    end = index
                    start = end
                    while start > 0 and (text[start - 1].isalnum() or text[start - 1] in "_$"):
                        start -= 1
                    return text[start:end].strip(), end
                depth -= 1
            index -= 1
        return "", -1

    @staticmethod
    def _argument_index(text: str, open_index: int, position: int) -> int:
        """How many top-level commas sit between the "(" and the caret.

        Nested parentheses and quoted literals are skipped, so a comma inside
        a nested call or a string value is never mistaken for an argument
        separator. The result is which argument the caret is currently in,
        0-based.
        """
        if open_index < 0:
            return 0
        depth = 0
        quote = ""
        argument = 0
        index = open_index + 1
        limit = min(position, len(text))
        while index < limit:
            char = text[index]
            if quote:
                if char == quote and text[index - 1] != "\\":
                    quote = ""
            elif char in ("'", '"'):
                quote = char
            elif char == "(":
                depth += 1
            elif char == ")":
                depth -= 1
            elif char == "," and depth == 0:
                argument += 1
            index += 1
        return argument

    #: Colour marking the argument the caret is currently in - distinct from
    #: the plain-bold function name, so the two kinds of emphasis read as
    #: different things at a glance.
    _CURRENT_ARG_COLOR = "#1a5fb4"

    @classmethod
    def _signature_html(cls, name: str, params: List[str], arg_index: int) -> str:
        """The signature as HTML, with the current argument in colour."""
        if not params:
            return f"<b>{name}</b>()"
        parts = [
            f'<span style="color:{cls._CURRENT_ARG_COLOR};">{param}</span>'
            if i == arg_index
            else param
            for i, param in enumerate(params)
        ]
        return f"<b>{name}</b>({', '.join(parts)})"

    def hide_popup(self) -> None:
        """Close the list and hand the caret back to the editor."""
        if self._popup is not None:
            try:
                self._popup.hide()
            except Exception:
                pass
        self._restore_caret()


# --------------------------------------------------------------------------- #
# Console diagnostic
# --------------------------------------------------------------------------- #


def force_complete() -> None:
    """Trigger completion from the Python Console, bypassing the keyboard.

    This isolates the two possible causes of "Ctrl+Space does nothing":

    * the popup appears -> the whole lookup path works and the problem is
      purely that the key is not reaching the editor (a shortcut conflict, or an
      input method grabbing Ctrl+Space at the OS level);
    * nothing happens -> the controller is not attached to the live editor,
      which usually means the installed plugin is running an older copy of this
      module. Check the reported __file__ against the plugin folder.

    Open the Expression Builder or Layer Filter, click into the editor, then::

        from rtl_bidi_editor.rtl_autocomplete import force_complete
        force_complete()
    """
    from qgis.PyQt.QtWidgets import QApplication, QPlainTextEdit

    print("=" * 68)
    print("RTL autocomplete - forced trigger")
    print("=" * 68)
    print(f"module file : {__file__}")

    editors = []
    focused = QApplication.focusWidget()
    if isinstance(focused, QPlainTextEdit):
        editors.append(focused)
    for widget in QApplication.allWidgets():
        if (
            isinstance(widget, QPlainTextEdit)
            and widget.objectName() == "rtlBidiOverlayEditor"
            and widget not in editors
        ):
            editors.append(widget)

    if not editors:
        print("No overlay editor found. Is the Expression Builder / Filter open?")
        print("=" * 68)
        return

    for editor in editors:
        controller = getattr(editor, "_custom_autocomplete", "MISSING")
        print(f"editor      : {editor.objectName()!r} visible={editor.isVisible()}")
        print(f"controller  : {controller}")
        if controller in (None, "MISSING"):
            print("  >>> The controller is not attached. The installed plugin is")
            print("      probably running an older rtl_autocomplete.py, or its")
            print("      import failed - check the Log Messages panel.")
            continue
        cursor_text = editor.toPlainText()[: editor.textCursor().position()]
        print(f"text before : {cursor_text!r}")
        print(f"detected    : {detect_field_name(cursor_text)!r}")
        try:
            controller.trigger()
            print("  trigger() called - a popup or a notice should be visible.")
        except Exception as exc:
            print(f"  trigger() raised: {exc}")
    print("=" * 68)


def diagnose(field_name: str = "") -> None:
    """Print why Ctrl+Space is or is not producing results.

    Run from the QGIS Python Console with the layer you are filtering selected
    in the layer tree::

        from rtl_bidi_editor.rtl_autocomplete import diagnose
        diagnose("COUNTRY")

    Uses print() rather than the message log on purpose, so it cannot raise the
    Log Messages dock and steal focus from a modal dialog.
    """
    print("=" * 68)
    print("RTL autocomplete diagnostic")
    print("=" * 68)

    usable, reason = Settings.autocomplete_is_usable()
    print(f"configuration usable : {usable}" + ("" if usable else f"  ({reason})"))
    print(f"enabled              : {Settings.autocomplete_enabled()}")

    layer = Settings.autocomplete_layer()
    print(f"lookup layer         : {layer.name() if layer else None}")
    if layer is not None:
        try:
            print(f"lookup layer fields  : {[f.name() for f in layer.fields()]}")
            print(f"lookup feature count : {layer.featureCount()}")
        except Exception as exc:
            print(f"  (could not read fields: {exc})")
    for key in ("table", "field_names", "value", "description", "group_code", "group_description"):
        print(f"  field[{key:17s}] = {Settings.field(key)!r}")

    context = _find_context_layer(None)
    print("-" * 68)
    if context is None:
        print("context layer        : NONE  <- table filtering cannot work")
        print("   Select the layer you are filtering in the Layers panel.")
    else:
        print(f"context layer        : {context.name()!r}")
        try:
            print(f"context source       : {context.source()}")
            print(f"context provider     : {context.providerType()}")
        except Exception:
            pass
        print(f"source_table_name()  : {source_table_name(context)!r}")

    candidates = resolve_table_candidates(None)
    print(f"table candidates     : {candidates}")

    if not field_name:
        print("\nPass a field name to test a lookup, e.g. diagnose('COUNTRY').")
        print("=" * 68)
        return

    if not usable:
        print("\nConfiguration is not usable; fix the above first.")
        print("=" * 68)
        return

    print("-" * 68)
    f_names = Settings.field("field_names")
    f_table = Settings.field("table")
    instance = cache()
    for label, exact, use_table in (
        ("exact + table", True, True),
        ("substring + table", False, True),
        ("exact, no table", True, False),
        ("substring, no table", False, False),
    ):
        expression = AutocompleteCache._expression(
            field_name, f_names, f_table if use_table else "", candidates, exact
        )
        rows = instance._run(
            layer,
            [n for n in (f_names, Settings.field("value"), f_table,
                         Settings.field("description"), Settings.field("group_code"),
                         Settings.field("group_description")) if n],
            expression,
            Settings.field("value"),
            Settings.field("description"),
            Settings.field("group_code"),
            Settings.field("group_description"),
        )
        print(f"{label:22s} -> {len(rows):4d} rows")
        print(f"{'':22s}    {expression}")
        _check_expression(expression)
        if rows:
            print(f"{'':22s}    sample: {[r.display for r in rows[:5]]}")

    # The single most useful output: what values actually exist in the lookup
    # table.  A mismatch between these and the table candidates above is the
    # usual reason a table-filtered lookup returns nothing.
    print("-" * 68)
    print("LOOKUP LAYER CONTENTS (repr, so hidden characters are visible)")
    _print_unique_values(layer, f_table, "Table Field")
    _print_unique_values(layer, Settings.field("field_names"), "Fields Names Field")

    print("-" * 68)
    print("PURE-PYTHON CROSS-CHECK (bypasses the expression engine)")
    _python_side_check(layer, field_name, candidates)
    print("=" * 68)


def _print_unique_values(layer, field_name: str, label: str, limit: int = 40) -> None:
    """Print the distinct values of one field, as repr().

    repr() matters: it exposes trailing spaces, non-breaking spaces and other
    invisible characters that make an apparently correct value fail to compare
    equal.  A plain print would hide exactly the problem we are hunting.
    """
    if layer is None or not field_name:
        print(f"  {label:22s}: (not configured)")
        return
    try:
        index = layer.fields().indexOf(field_name)
        if index < 0:
            print(f"  {label:22s}: field {field_name!r} NOT FOUND in the layer")
            return
        field = layer.fields().at(index)
        values = sorted(
            repr(str(v)) for v in layer.uniqueValues(index, limit + 1) if v is not None
        )
        suffix = " ..." if len(values) > limit else ""
        print(f"  {label:22s} field={field_name!r} type={field.typeName()}")
        print(f"  {'':22s} values={values[:limit]}{suffix}")
    except Exception as exc:
        print(f"  {label:22s}: could not read values ({exc})")


def _python_side_check(layer, field_name: str, candidates) -> None:
    """Compare in pure Python, bypassing the expression engine entirely.

    This is the decisive test.  If Python finds matching rows but none of the
    expression passes do, the fault is in the query or the provider.  If Python
    finds none either, the stored data genuinely differs from what the attribute
    table appears to show - check the repr() output above for hidden characters,
    and check whether the field uses a value map or value relation widget, which
    displays a label while storing a different code.
    """
    f_names = Settings.field("field_names")
    f_table = Settings.field("table")
    if layer is None or not f_names:
        return

    wanted_field = field_name.strip().lower()
    wanted_tables = {c.strip().lower() for c in candidates}

    field_hits = 0
    both_hits = 0
    table_values_seen = set()
    samples = []
    try:
        for feature in layer.getFeatures():
            raw_field = feature[f_names] if f_names else None
            if raw_field is None:
                continue
            if str(raw_field).strip().lower() != wanted_field:
                continue
            field_hits += 1
            if not f_table:
                continue
            raw_table = feature[f_table]
            text = "" if raw_table is None else str(raw_table)
            table_values_seen.add(repr(text))
            if text.strip().lower() in wanted_tables:
                both_hits += 1
                if len(samples) < 5:
                    samples.append(repr(text))
    except Exception as exc:
        print(f"  python-side scan failed: {exc}")
        return

    print(f"  rows matching field {field_name!r}          : {field_hits}")
    if f_table:
        print(f"  ...of which the table also matches      : {both_hits}")
        print(f"  table values present on those rows      : {sorted(table_values_seen)}")
        if samples:
            print(f"  matching table values                   : {samples}")
        if field_hits and not both_hits:
            print("  >>> The field matches but the table does not. Compare the")
            print("      repr() values above with the table candidates; look for")
            print("      trailing spaces or a value-map/value-relation widget.")
        elif both_hits:
            print("  >>> Python finds matching rows. If the expression passes")
            print("      above returned 0, the fault is in the query, not the data.")


def _check_expression(expression: str) -> bool:
    """Report a parser error in a generated expression."""
    try:
        parsed = QgsExpression(expression)
        if parsed.hasParserError():
            print(f"  PARSER ERROR: {parsed.parserErrorString()}")
            return False
    except Exception as exc:
        print(f"  could not parse: {exc}")
        return False
    return True
